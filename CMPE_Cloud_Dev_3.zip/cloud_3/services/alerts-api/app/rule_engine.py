"""
Alert Rule Engine
Implements context-aware decision tables for 6 core alert types:
1. Speeding (Context-Aware)
2. Excess Idle
3. Route Deviation / Geofence
4. Maintenance Scheduling
5. Connectivity / Offline
6. SLA / ETA Breach
"""

from datetime import datetime, timedelta
from typing import Optional, Dict, Any
import logging

logger = logging.getLogger(__name__)


class AlertRule:
    """Base alert rule"""
    
    def __init__(self, rule_id: str, name: str, severity: str, actions: dict):
        self.rule_id = rule_id
        self.name = name
        self.severity = severity
        self.actions = actions
    
    def evaluate(self, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        """Evaluate rule against context, return alert if triggered"""
        raise NotImplementedError


class SpeedingRule(AlertRule):
    """Context-aware speeding rule"""
    
    def evaluate(self, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        speed = context.get('speed', 0)
        road_limit = context.get('road_limit_kmph', 60)
        road_type = context.get('road_type', 'urban')
        consecutive_violations = context.get('consecutive_violations', 0)
        
        delta = speed - road_limit
        
        # Decision table
        if delta >= 30 and consecutive_violations >= 3:
            return self._create_alert(
                context, "HIGH",
                f"Severe speeding: {delta}km/h over limit ({consecutive_violations} violations)",
                ["notify_ops", "sms_driver"]
            )
        elif delta >= 20 and road_type == "highway" and consecutive_violations >= 2:
            return self._create_alert(
                context, "MEDIUM",
                f"Highway speeding: {delta}km/h over limit",
                ["email_driver"]
            )
        elif delta >= 15 and road_type == "urban" and consecutive_violations >= 2:
            return self._create_alert(
                context, "MEDIUM",
                f"Urban speeding: {delta}km/h over limit",
                ["email_driver"]
            )
        elif delta >= 10 and road_type == "school_zone" and consecutive_violations >= 1:
            return self._create_alert(
                context, "HIGH",
                f"School zone speeding: {delta}km/h over limit",
                ["escalate", "sms_driver"]
            )
        elif delta >= 5 and consecutive_violations >= 3:
            return self._create_alert(
                context, "LOW",
                f"Repeated minor speeding: {delta}km/h over limit",
                ["score_impact"]
            )
        
        return None
    
    def _create_alert(self, context, severity, summary, actions):
        return {
            "vehicle_id": context['vehicle_id'],
            "rule_id": self.rule_id,
            "severity": severity,
            "summary": summary,
            "details": {
                "speed": context['speed'],
                "limit": context.get('road_limit_kmph'),
                "road_type": context.get('road_type'),
                "location": context.get('location')
            },
            "actions": actions
        }


class IdleRule(AlertRule):
    """Excess idle time rule"""
    
    def evaluate(self, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        engine_on = context.get('engine_status') == 'ON' or context.get('engine_status') == 'IDLE'
        speed = context.get('speed', 0)
        idle_minutes = context.get('idle_minutes', 0)
        ambient_temp = context.get('ambient_temp')
        
        if not engine_on or speed > 0:
            return None
        
        # Decision table
        if idle_minutes >= 30:
            return {
                "vehicle_id": context['vehicle_id'],
                "rule_id": self.rule_id,
                "severity": "HIGH",
                "summary": f"Excessive idle: {idle_minutes} minutes",
                "details": {
                    "idle_minutes": idle_minutes,
                    "ambient_temp": ambient_temp
                },
                "actions": ["notify_dispatcher"]
            }
        elif idle_minutes >= 20:
            return {
                "vehicle_id": context['vehicle_id'],
                "rule_id": self.rule_id,
                "severity": "MEDIUM",
                "summary": f"Extended idle: {idle_minutes} minutes",
                "details": {"idle_minutes": idle_minutes},
                "actions": ["app_ping"]
            }
        elif idle_minutes >= 10 and ambient_temp and (ambient_temp < 0 or ambient_temp > 35):
            return {
                "vehicle_id": context['vehicle_id'],
                "rule_id": self.rule_id,
                "severity": "LOW",
                "summary": f"Idle in extreme conditions: {idle_minutes} min, {ambient_temp}°C",
                "details": {"idle_minutes": idle_minutes, "ambient_temp": ambient_temp},
                "actions": ["advisory"]
            }
        
        return None


class RouteDeviationRule(AlertRule):
    """Route deviation / geofence rule"""
    
    def evaluate(self, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        deviation_meters = context.get('deviation_meters', 0)
        is_planned = context.get('is_planned_route', False)
        delay_minutes = context.get('delay_minutes', 0)
        
        # Decision table
        if deviation_meters >= 1000 and not is_planned and delay_minutes >= 10:
            return {
                "vehicle_id": context['vehicle_id'],
                "rule_id": self.rule_id,
                "severity": "HIGH",
                "summary": f"Major route deviation: {deviation_meters}m off course",
                "details": {
                    "deviation_meters": deviation_meters,
                    "delay_minutes": delay_minutes
                },
                "actions": ["notify_ops", "driver_confirmation"]
            }
        elif 200 <= deviation_meters < 1000 and not is_planned and delay_minutes >= 5:
            return {
                "vehicle_id": context['vehicle_id'],
                "rule_id": self.rule_id,
                "severity": "MEDIUM",
                "summary": f"Route deviation: {deviation_meters}m off course",
                "details": {"deviation_meters": deviation_meters},
                "actions": ["app_ping"]
            }
        elif deviation_meters <= 200 and not is_planned:
            return {
                "vehicle_id": context['vehicle_id'],
                "rule_id": self.rule_id,
                "severity": "LOW",
                "summary": f"Minor deviation: {deviation_meters}m",
                "details": {"deviation_meters": deviation_meters},
                "actions": ["log"]
            }
        
        return None


class MaintenanceRule(AlertRule):
    """Maintenance scheduling rule"""
    
    def evaluate(self, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        km_since_service = context.get('km_since_last_service', 0)
        days_since_service = context.get('days_since_service', 0)
        has_critical_dtc = context.get('has_critical_dtc', False)
        health_score = context.get('predictive_health_score', 0.5)
        
        # Decision table
        if km_since_service >= 10000 and has_critical_dtc:
            return {
                "vehicle_id": context['vehicle_id'],
                "rule_id": self.rule_id,
                "severity": "HIGH",
                "summary": f"Critical maintenance required: {km_since_service}km since service",
                "details": {
                    "km_since_service": km_since_service,
                    "has_critical_dtc": has_critical_dtc
                },
                "actions": ["pull_from_service", "create_ticket"]
            }
        elif 7500 <= km_since_service < 10000 and health_score >= 0.7:
            return {
                "vehicle_id": context['vehicle_id'],
                "rule_id": self.rule_id,
                "severity": "MEDIUM",
                "summary": f"Maintenance due soon: {km_since_service}km since service",
                "details": {"km_since_service": km_since_service, "health_score": health_score},
                "actions": ["schedule_within_7_days"]
            }
        elif days_since_service >= 180 and health_score >= 0.5:
            return {
                "vehicle_id": context['vehicle_id'],
                "rule_id": self.rule_id,
                "severity": "MEDIUM",
                "summary": f"Scheduled maintenance overdue: {days_since_service} days",
                "details": {"days_since_service": days_since_service},
                "actions": ["schedule_within_14_days"]
            }
        
        return None


class ConnectivityRule(AlertRule):
    """Connectivity / offline rule"""
    
    def evaluate(self, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        minutes_since_last = context.get('minutes_since_last_telemetry', 0)
        gps_fix = context.get('gps_fix', 'ok')
        ignition = context.get('ignition', 'OFF')
        
        # Decision table
        if minutes_since_last >= 30 and gps_fix == 'lost' and ignition == 'ON':
            return {
                "vehicle_id": context['vehicle_id'],
                "rule_id": self.rule_id,
                "severity": "HIGH",
                "summary": f"Vehicle offline for {minutes_since_last} minutes (engine ON)",
                "details": {
                    "minutes_offline": minutes_since_last,
                    "gps_fix": gps_fix,
                    "ignition": ignition
                },
                "actions": ["call_driver", "create_ticket"]
            }
        elif 10 <= minutes_since_last < 30 and gps_fix == 'lost':
            return {
                "vehicle_id": context['vehicle_id'],
                "rule_id": self.rule_id,
                "severity": "MEDIUM",
                "summary": f"GPS signal lost for {minutes_since_last} minutes",
                "details": {"minutes_offline": minutes_since_last},
                "actions": ["monitor"]
            }
        elif minutes_since_last >= 60 and ignition == 'OFF':
            return {
                "vehicle_id": context['vehicle_id'],
                "rule_id": self.rule_id,
                "severity": "LOW",
                "summary": f"Vehicle parked/offline for {minutes_since_last} minutes",
                "details": {"minutes_offline": minutes_since_last, "ignition": ignition},
                "actions": ["log"]
            }
        
        return None


class SLARule(AlertRule):
    """SLA / ETA breach rule"""
    
    def evaluate(self, context: Dict[str, Any]) -> Optional[Dict[str, Any]]:
        eta_delta_minutes = context.get('eta_delta_minutes', 0)
        priority = context.get('priority', 'C')
        window_end_minutes = context.get('window_end_minutes', 120)
        
        # Decision table
        if eta_delta_minutes >= 20 and priority == 'A' and window_end_minutes <= 30:
            return {
                "vehicle_id": context['vehicle_id'],
                "rule_id": self.rule_id,
                "severity": "HIGH",
                "summary": f"Priority A delivery at risk: {eta_delta_minutes} min late",
                "details": {
                    "eta_delta_minutes": eta_delta_minutes,
                    "priority": priority,
                    "window_end_minutes": window_end_minutes
                },
                "actions": ["notify_customer", "reroute", "escalate"]
            }
        elif 10 <= eta_delta_minutes < 20 and priority in ['A', 'B'] and window_end_minutes <= 60:
            return {
                "vehicle_id": context['vehicle_id'],
                "rule_id": self.rule_id,
                "severity": "MEDIUM",
                "summary": f"Delivery delay expected: {eta_delta_minutes} min",
                "details": {"eta_delta_minutes": eta_delta_minutes, "priority": priority},
                "actions": ["notify_customer"]
            }
        elif 5 <= eta_delta_minutes < 10:
            return {
                "vehicle_id": context['vehicle_id'],
                "rule_id": self.rule_id,
                "severity": "LOW",
                "summary": f"Minor delay: {eta_delta_minutes} min",
                "details": {"eta_delta_minutes": eta_delta_minutes},
                "actions": ["log"]
            }
        
        return None


class RuleEngine:
    """Main rule engine coordinator"""
    
    def __init__(self):
        self.rules = []
        self._init_rules()
    
    def _init_rules(self):
        """Initialize all rule instances"""
        self.rules = [
            SpeedingRule("rule-speeding", "Speeding (Context-Aware)", "MEDIUM", {}),
            IdleRule("rule-idle", "Excess Idle", "HIGH", {}),
            RouteDeviationRule("rule-route", "Route Deviation", "HIGH", {}),
            MaintenanceRule("rule-maintenance", "Maintenance Scheduling", "MEDIUM", {}),
            ConnectivityRule("rule-connectivity", "Connectivity Lost", "HIGH", {}),
            SLARule("rule-sla", "SLA Breach", "HIGH", {})
        ]
    
    def evaluate_all(self, context: Dict[str, Any]) -> list[Dict[str, Any]]:
        """Evaluate all rules against context"""
        alerts = []
        
        for rule in self.rules:
            try:
                alert = rule.evaluate(context)
                if alert:
                    alerts.append(alert)
            except Exception as e:
                logger.error(f"Error evaluating rule {rule.name}: {e}")
        
        return alerts
    
    def should_suppress(self, alert: Dict[str, Any], vehicle_status: str) -> bool:
        """Check if alert should be suppressed"""
        # Suppress Speeding & Idle when vehicle in maintenance
        if vehicle_status == "maintenance":
            rule_id = alert.get('rule_id', '')
            if 'speeding' in rule_id or 'idle' in rule_id:
                return True
        
        return False


# Global rule engine instance
rule_engine = RuleEngine()

