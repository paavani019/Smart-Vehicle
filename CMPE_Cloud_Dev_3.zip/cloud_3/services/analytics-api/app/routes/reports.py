"""Report generation routes"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from pydantic import BaseModel
from typing import Optional, Dict
from datetime import datetime, date
from uuid import uuid4
import io
import json

from app.database import get_db

router = APIRouter()


class ReportGenerateRequest(BaseModel):
    """Report generation request"""
    kind: str  # daily, weekly, utilization, driver_scorecards
    date_range: Dict[str, str]  # {"start": "2025-01-01", "end": "2025-01-31"}
    fleet_scope: Optional[list[str]] = None  # vehicle IDs, None = all


@router.post("/generate")
async def generate_report(
    request: ReportGenerateRequest,
    db: AsyncSession = Depends(get_db)
):
    """
    Generate a report
    Returns: report ID and status (will generate PDF/CSV asynchronously)
    """
    
    report_id = uuid4()
    
    # Insert report record
    query = text("""
        INSERT INTO reports (id, kind, period, status, created_at)
        VALUES (:id, :kind, :period, :status, :created_at)
        RETURNING id
    """)
    
    period = {
        "start": request.date_range.get("start"),
        "end": request.date_range.get("end"),
        "fleet_scope": request.fleet_scope
    }
    
    await db.execute(query, {
        "id": report_id,
        "kind": request.kind,
        "period": json.dumps(period),  # Convert dict to JSON string
        "status": "pending",
        "created_at": datetime.utcnow()
    })
    await db.commit()
    
    # In production, this would trigger async report generation
    # For now, immediately mark as completed with a mock URL
    update_query = text("""
        UPDATE reports
        SET status = 'completed', url = :url
        WHERE id = :id
    """)
    
    mock_url = f"http://minio:9000/reports/{report_id}.pdf"
    
    await db.execute(update_query, {
        "id": report_id,
        "url": mock_url
    })
    await db.commit()
    
    return {
        "report_id": str(report_id),
        "status": "completed",
        "url": mock_url,
        "kind": request.kind,
        "message": f"{request.kind.title()} report generated successfully"
    }


@router.get("/{report_id}")
async def get_report(
    report_id: str,
    db: AsyncSession = Depends(get_db)
):
    """Get report status and download URL"""
    
    query = text("""
        SELECT id, kind, period, url, status, created_at
        FROM reports
        WHERE id = :report_id
    """)
    
    result = await db.execute(query, {"report_id": report_id})
    row = result.fetchone()
    
    if not row:
        raise HTTPException(status_code=404, detail=f"Report {report_id} not found")
    
    return {
        "report_id": str(row[0]),
        "kind": row[1],
        "period": row[2],
        "url": row[3],
        "status": row[4],
        "created_at": row[5].isoformat()
    }


@router.get("/")
async def list_reports(
    kind: Optional[str] = None,
    limit: int = 20,
    db: AsyncSession = Depends(get_db)
):
    """List recent reports"""
    
    if kind:
        query = text("""
            SELECT id, kind, period, url, status, created_at
            FROM reports
            WHERE kind = :kind
            ORDER BY created_at DESC
            LIMIT :limit
        """)
        result = await db.execute(query, {"kind": kind, "limit": limit})
    else:
        query = text("""
            SELECT id, kind, period, url, status, created_at
            FROM reports
            ORDER BY created_at DESC
            LIMIT :limit
        """)
        result = await db.execute(query, {"limit": limit})
    
    rows = result.fetchall()
    
    reports = []
    for row in rows:
        reports.append({
            "report_id": str(row[0]),
            "kind": row[1],
            "period": row[2],
            "url": row[3],
            "status": row[4],
            "created_at": row[5].isoformat()
        })
    
    return {
        "reports": reports,
        "total": len(reports)
    }

