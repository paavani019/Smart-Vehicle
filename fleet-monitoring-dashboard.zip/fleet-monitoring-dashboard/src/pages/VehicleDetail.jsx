import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { fetchVehicle } from '../api/api';

const VehicleDetail = () => {
  const { id } = useParams();
  const [vehicle, setVehicle] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadVehicle = async () => {
      try {
        const data = await fetchVehicle(id);
        setVehicle(data);
      } catch (error) {
        console.error('Error loading vehicle:', error);
      } finally {
        setLoading(false);
      }
    };

    loadVehicle();
    const interval = setInterval(loadVehicle, 30000); // Refresh every 30 seconds

    return () => clearInterval(interval);
  }, [id]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-gray-500">Loading vehicle details...</div>
      </div>
    );
  }

  if (!vehicle) {
    return (
      <div className="px-4 py-6">
        <div className="bg-white shadow rounded-lg p-8 text-center">
          <h3 className="text-lg font-medium text-gray-900 mb-2">Vehicle Not Found</h3>
          <Link to="/" className="text-primary-600 hover:text-primary-800">
            ← Back to Overview
          </Link>
        </div>
      </div>
    );
  }

  const getStatusColor = (status) => {
    switch (status) {
      case 'active':
        return 'bg-green-100 text-green-800';
      case 'idle':
        return 'bg-yellow-100 text-yellow-800';
      case 'maintenance':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getComponentStatusColor = (condition) => {
    if (condition >= 80) return 'text-green-600';
    if (condition >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  // Format telemetry data for charts
  const chartData = vehicle.telemetryHistory?.map((item) => ({
    time: new Date(item.timestamp).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' }),
    speed: Math.round(item.speed),
    fuel: Math.round(item.fuel),
  })) || [];

  return (
    <div className="px-4 py-6">
      <div className="mb-6">
        <Link to="/" className="text-primary-600 hover:text-primary-800 text-sm font-medium">
          ← Back to Overview
        </Link>
      </div>

      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900">{vehicle.name}</h2>
        <p className="text-gray-500">Vehicle ID: {vehicle.id}</p>
      </div>

      {/* Status Card */}
      <div className="bg-white shadow rounded-lg p-6 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <h3 className="text-sm font-medium text-gray-500 mb-2">Status</h3>
            <span className={`px-3 py-1 inline-flex text-sm leading-5 font-semibold rounded-full ${getStatusColor(vehicle.status)}`}>
              {vehicle.status}
            </span>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500 mb-2">Current Speed</h3>
            <p className="text-2xl font-semibold text-gray-900">{vehicle.speed} km/h</p>
          </div>
          <div>
            <h3 className="text-sm font-medium text-gray-500 mb-2">Fuel Level</h3>
            <div className="flex items-center">
              <p className="text-2xl font-semibold text-gray-900 mr-3">{vehicle.fuel}%</p>
              <div className="w-32 bg-gray-200 rounded-full h-3">
                <div
                  className={`h-3 rounded-full ${
                    vehicle.fuel > 50 ? 'bg-green-500' : vehicle.fuel > 20 ? 'bg-yellow-500' : 'bg-red-500'
                  }`}
                  style={{ width: `${vehicle.fuel}%` }}
                ></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Telemetry Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Speed Over Time</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="time" />
              <YAxis label={{ value: 'Speed (km/h)', angle: -90, position: 'insideLeft' }} />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="speed" stroke="#3b82f6" strokeWidth={2} name="Speed (km/h)" />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="bg-white shadow rounded-lg p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Fuel Level Over Time</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="time" />
              <YAxis label={{ value: 'Fuel (%)', angle: -90, position: 'insideLeft' }} />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="fuel" stroke="#10b981" strokeWidth={2} name="Fuel (%)" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Maintenance Info */}
      {vehicle.maintenance && (
        <div className="bg-white shadow rounded-lg p-6 mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Maintenance Information</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <h4 className="text-sm font-medium text-gray-500 mb-2">Health Score</h4>
              <div className="flex items-center">
                <div className="text-3xl font-bold text-gray-900 mr-3">{vehicle.maintenance.healthScore}%</div>
                <div className="w-32 bg-gray-200 rounded-full h-3">
                  <div
                    className={`h-3 rounded-full ${
                      vehicle.maintenance.healthScore >= 80 ? 'bg-green-500' : vehicle.maintenance.healthScore >= 60 ? 'bg-yellow-500' : 'bg-red-500'
                    }`}
                    style={{ width: `${vehicle.maintenance.healthScore}%` }}
                  ></div>
                </div>
              </div>
            </div>
            <div>
              <h4 className="text-sm font-medium text-gray-500 mb-2">Service Schedule</h4>
              <p className="text-sm text-gray-900">Last Service: {vehicle.maintenance.lastService}</p>
              <p className="text-sm text-gray-900">Next Service: {vehicle.maintenance.nextService}</p>
            </div>
          </div>
          <div>
            <h4 className="text-sm font-medium text-gray-500 mb-3">Component Status</h4>
            <div className="space-y-2">
              {vehicle.maintenance.components?.map((component, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                  <div>
                    <p className="text-sm font-medium text-gray-900">{component.name}</p>
                    <p className="text-xs text-gray-500">{component.status}</p>
                  </div>
                  <div className={`text-lg font-semibold ${getComponentStatusColor(component.condition)}`}>
                    {component.condition}%
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Location Info */}
      <div className="bg-white shadow rounded-lg p-6">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Location</h3>
        <p className="text-sm text-gray-600 mb-2">
          <span className="font-medium">Coordinates:</span> {vehicle.lat?.toFixed(4)}, {vehicle.lng?.toFixed(4)}
        </p>
        <Link
          to={`/map`}
          className="text-primary-600 hover:text-primary-800 text-sm font-medium"
        >
          View on Map →
        </Link>
      </div>
    </div>
  );
};

export default VehicleDetail;

