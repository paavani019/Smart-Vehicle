"""Maintenance prediction and reporting routes"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text
from datetime import datetime, date, timedelta
from uuid import UUID, uuid4
import logging

from app.database import get_db, get_timescale_db
from app.schemas import (
    MaintenancePrediction,
    MaintenanceReportCreate,
    MaintenanceReportResponse,
    MaintenanceAlert
)
from app.ml.model_manager import model_manager

router = APIRouter()
logger = logging.getLogger(__name__)


async def extract_features(vehicle_id: str, timescale_db: AsyncSession) -> dict:
    """Extract features from telemetry data for ML prediction"""
    
    # Query last 7 days of telemetry
    query = text("""
        SELECT 
            AVG(coolant_temp) as avg_coolant_temp,
            AVG(battery_voltage) as avg_battery_voltage,
            AVG(rpm) as avg_rpm,
            MAX(speed) as max_speed,
            SUM(CASE WHEN idle_flag THEN 1 ELSE 0 END)::float / COUNT(*)::float as idle_time_pct,
            MAX(odometer_km) as current_odometer
        FROM telemetry_records
        WHERE vehicle_id = :vehicle_id
        AND ts >= NOW() - INTERVAL '7 days'
    """)
    
    result = await timescale_db.execute(query, {"vehicle_id": vehicle_id})
    row = result.fetchone()
    
    if not row or row[0] is None:
        # No data available, return defaults
        return {
            'avg_coolant_temp': 85.0,
            'avg_battery_voltage': 12.5,
            'avg_rpm': 2000,
            'max_speed': 80,
            'idle_time_pct': 0.1,
            'days_since_service': 30,
            'odometer_km': 15000
        }
    
    # Get vehicle service history
    service_query = text("""
        SELECT 
            COALESCE(EXTRACT(EPOCH FROM (NOW() - MAX(last_service_date)))/86400, 30) as days_since_service,
            COALESCE(odometer_km, 15000) as odometer_km
        FROM vehicles
        WHERE vehicle_id = :vehicle_id
    """)
    
    service_result = await get_db().__anext__()
    service_data = await service_result.execute(service_query, {"vehicle_id": vehicle_id})
    service_row = service_data.fetchone()
    
    return {
        'avg_coolant_temp': float(row[0]) if row[0] else 85.0,
        'avg_battery_voltage': float(row[1]) if row[1] else 12.5,
        'avg_rpm': float(row[2]) if row[2] else 2000,
        'max_speed': float(row[3]) if row[3] else 80,
        'idle_time_pct': float(row[4]) if row[4] else 0.1,
        'days_since_service': float(service_row[0]) if service_row else 30,
        'odometer_km': float(service_row[1] if service_row and service_row[1] else row[5] if row[5] else 15000)
    }


@router.get("/predict/{vehicle_id}", response_model=MaintenancePrediction)
async def predict_maintenance(
    vehicle_id: str,
    db: AsyncSession = Depends(get_db),
    timescale_db: AsyncSession = Depends(get_timescale_db)
):
    """
    Predict maintenance needs for a vehicle
    Returns predicted issue, confidence, next service due, health score, and recommended action
    """
    
    # Check if vehicle exists
    result = await db.execute(
        text("SELECT vehicle_id, next_service_due FROM vehicles WHERE vehicle_id = :vehicle_id"),
        {"vehicle_id": vehicle_id}
    )
    vehicle = result.fetchone()
    if not vehicle:
        raise HTTPException(status_code=404, detail=f"Vehicle {vehicle_id} not found")
    
    # Extract features
    features = await extract_features(vehicle_id, timescale_db)
    
    # Get prediction
    predicted_issue, confidence, severity = model_manager.predict_maintenance(features)
    
    # Calculate health score
    health_score = model_manager.calculate_health_score(features)
    
    # Determine next service due
    if severity in ["High", "Critical"]:
        next_service_due = date.today() + timedelta(days=7)
        recommended_action = f"Schedule maintenance within 7 days for {predicted_issue}"
    elif severity == "Medium":
        next_service_due = date.today() + timedelta(days=14)
        recommended_action = f"Schedule maintenance within 14 days for {predicted_issue}"
    else:
        next_service_due = vehicle[1] if vehicle[1] else date.today() + timedelta(days=90)
        recommended_action = f"Monitor condition. {predicted_issue}"
    
    return MaintenancePrediction(
        vehicle_id=vehicle_id,
        predicted_issue=predicted_issue,
        confidence=confidence,
        next_service_due=next_service_due,
        health_score=health_score,
        severity=severity,
        recommended_action=recommended_action
    )


@router.post("/report", response_model=MaintenanceReportResponse)
async def create_maintenance_report(
    report: MaintenanceReportCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create a new maintenance report"""
    
    # Insert maintenance report
    query = text("""
        INSERT INTO maintenance_reports 
        (id, vehicle_id, report_date, cost, parts_changed, remarks, performed_by, created_at)
        VALUES (:id, :vehicle_id, :report_date, :cost, :parts_changed, :remarks, :performed_by, :created_at)
        RETURNING id, vehicle_id, report_date, cost, parts_changed, remarks, performed_by, created_at
    """)
    
    report_id = uuid4()
    result = await db.execute(query, {
        "id": report_id,
        "vehicle_id": report.vehicle_id,
        "report_date": report.report_date,
        "cost": report.cost,
        "parts_changed": report.parts_changed,
        "remarks": report.remarks,
        "performed_by": report.performed_by,
        "created_at": datetime.utcnow()
    })
    await db.commit()
    
    row = result.fetchone()
    
    return MaintenanceReportResponse(
        id=row[0],
        vehicle_id=row[1],
        report_date=row[2],
        cost=row[3],
        parts_changed=row[4],
        remarks=row[5],
        performed_by=row[6],
        created_at=row[7]
    )


@router.get("/alerts", response_model=list[MaintenanceAlert])
async def get_maintenance_alerts(
    db: AsyncSession = Depends(get_db)
):
    """Get open predictive maintenance alerts"""
    
    query = text("""
        SELECT 
            id,
            vehicle_id,
            component,
            predicted_issue,
            confidence,
            severity,
            due_date,
            recommended_action,
            created_at
        FROM maintenance_predictions
        WHERE due_date >= CURRENT_DATE - INTERVAL '30 days'
        ORDER BY 
            CASE severity
                WHEN 'Critical' THEN 1
                WHEN 'High' THEN 2
                WHEN 'Medium' THEN 3
                ELSE 4
            END,
            due_date ASC
        LIMIT 50
    """)
    
    result = await db.execute(query)
    rows = result.fetchall()
    
    alerts = []
    for row in rows:
        alerts.append(MaintenanceAlert(
            id=row[0],
            vehicle_id=row[1],
            component=row[2],
            predicted_issue=row[3],
            confidence=float(row[4]),
            severity=row[5],
            due_date=row[6],
            recommended_action=row[7],
            created_at=row[8]
        ))
    
    return alerts

