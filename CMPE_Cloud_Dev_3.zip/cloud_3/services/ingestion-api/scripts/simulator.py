"""
Telemetry simulator - generates realistic vehicle data
Run with: python scripts/simulator.py
"""

import asyncio
import httpx
import random
from datetime import datetime, timezone
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))


# Predefined routes (lat, lon waypoints)
ROUTES = {
    "VEH-001": [(30.2672, -97.7431), (30.2820, -97.7400), (30.2950, -97.7350)],  # Austin, TX
    "VEH-002": [(32.7767, -96.7970), (32.7900, -96.8100), (32.8050, -96.8200)],  # Dallas, TX
    "VEH-003": [(29.7604, -95.3698), (29.7750, -95.3800), (29.7900, -95.3900)],  # Houston, TX
    "VEH-004": [(33.4484, -112.0740), (33.4600, -112.0800), (33.4750, -112.0900)],  # Phoenix, AZ
    "VEH-005": [(34.0522, -118.2437), (34.0650, -118.2500), (34.0800, -118.2600)],  # LA, CA
    "VEH-006": [(37.7749, -122.4194), (37.7850, -122.4250), (37.7950, -122.4300)],  # SF, CA
    "VEH-007": [(40.7128, -74.0060), (40.7250, -74.0100), (40.7400, -74.0150)],  # NYC, NY
    "VEH-009": [(41.8781, -87.6298), (41.8900, -87.6350), (41.9050, -87.6400)],  # Chicago, IL
    "VEH-010": [(39.7392, -104.9903), (39.7500, -105.0000), (39.7650, -105.0100)],  # Denver, CO
}


class VehicleSimulator:
    def __init__(self, vehicle_id: str, route: list, base_url: str = "http://localhost:8001"):
        self.vehicle_id = vehicle_id
        self.route = route
        self.base_url = base_url
        self.position_index = 0
        self.odometer = random.uniform(10000, 30000)
        self.access_token = None
    
    async def login(self):
        """Login and get access token"""
        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    f"{self.base_url}/v1/auth/login",
                    json={
                        "email": "admin@fleet.com",
                        "password": "admin123"
                    },
                    timeout=10.0
                )
                if response.status_code == 200:
                    data = response.json()
                    self.access_token = data["access_token"]
                    print(f"✅ {self.vehicle_id}: Authenticated")
                    return True
                else:
                    print(f"❌ {self.vehicle_id}: Login failed: {response.status_code}")
                    return False
            except Exception as e:
                print(f"❌ {self.vehicle_id}: Login error: {e}")
                return False
    
    def generate_telemetry(self) -> dict:
        """Generate realistic telemetry data"""
        # Get current position
        lat, lon = self.route[self.position_index % len(self.route)]
        
        # Add some random variation
        lat += random.uniform(-0.001, 0.001)
        lon += random.uniform(-0.001, 0.001)
        
        # Generate speed (simulate traffic patterns)
        if random.random() < 0.1:  # 10% chance of being stopped
            speed = 0
            idle = True
        else:
            speed = random.uniform(30, 90)  # 30-90 km/h
            idle = False
        
        # Update odometer
        self.odometer += speed / 3600  # Rough estimate
        
        # Generate other telemetry
        rpm = 0 if speed == 0 else int(speed * 35 + random.uniform(-200, 200))
        gear = 0 if speed == 0 else min(6, max(1, int(speed / 20) + 1))
        coolant_temp = random.uniform(85, 95) if speed > 0 else random.uniform(70, 85)
        battery_voltage = random.uniform(12.0, 14.5)
        fuel_level = random.uniform(30, 100)
        
        # Move to next waypoint
        self.position_index += 1
        
        return {
            "vehicleId": self.vehicle_id,
            "ts": datetime.now(timezone.utc).isoformat(),
            "gps": [lat, lon],
            "speed": round(speed, 2),
            "rpm": rpm,
            "gear": gear,
            "coolantTemp": round(coolant_temp, 1),
            "batteryVoltage": round(battery_voltage, 2),
            "odometerKm": round(self.odometer, 2),
            "fuelLevel": round(fuel_level, 1),
            "engineStatus": "ON" if speed > 0 else "IDLE"
        }
    
    async def send_telemetry(self, telemetry: dict) -> bool:
        """Send telemetry to API"""
        if not self.access_token:
            if not await self.login():
                return False
        
        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    f"{self.base_url}/v1/telemetry/batch",
                    json={"records": [telemetry]},
                    headers={"Authorization": f"Bearer {self.access_token}"},
                    timeout=10.0
                )
                if response.status_code == 200:
                    data = response.json()
                    print(f"✅ {self.vehicle_id}: Sent telemetry (speed={telemetry['speed']}km/h)")
                    return True
                else:
                    print(f"⚠️ {self.vehicle_id}: Failed to send telemetry: {response.status_code}")
                    return False
            except Exception as e:
                print(f"❌ {self.vehicle_id}: Error sending telemetry: {e}")
                return False
    
    async def run(self, interval: int = 5):
        """Run simulator loop"""
        print(f"🚗 {self.vehicle_id}: Starting simulator (interval={interval}s)")
        
        while True:
            telemetry = self.generate_telemetry()
            await self.send_telemetry(telemetry)
            await asyncio.sleep(interval)


async def main():
    """Run simulators for all vehicles"""
    print("🎮 Starting vehicle telemetry simulator...")
    print("📡 Sending data to http://localhost:8001")
    print("⏱️  Interval: 5 seconds per vehicle")
    print("=" * 60)
    
    # Create simulators for each vehicle
    simulators = [
        VehicleSimulator(vehicle_id, route)
        for vehicle_id, route in ROUTES.items()
    ]
    
    # Run all simulators concurrently
    tasks = [simulator.run(interval=5) for simulator in simulators]
    
    try:
        await asyncio.gather(*tasks)
    except KeyboardInterrupt:
        print("\n\n⏹️  Simulator stopped by user")


if __name__ == "__main__":
    asyncio.run(main())

