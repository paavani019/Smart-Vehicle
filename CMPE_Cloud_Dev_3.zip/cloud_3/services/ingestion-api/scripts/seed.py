"""
Seed script to populate database with sample data
Run with: python scripts/seed.py
"""

import asyncio
import sys
from pathlib import Path

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from sqlalchemy import text
from datetime import datetime, timedelta
import bcrypt
import uuid

from app.database import AsyncSessionLocal, TimescaleSessionLocal
from app.models import User, Vehicle, Driver, IngestionJob
from app.models import UserRole, VehicleStatus


def hash_password(password: str) -> str:
    """Hash a password using bcrypt"""
    return bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')


async def seed_users():
    """Seed users"""
    async with AsyncSessionLocal() as session:
        # Check if users already exist
        result = await session.execute(text("SELECT COUNT(*) FROM users"))
        count = result.scalar()
        if count > 0:
            print("✅ Users already seeded")
            return
        
        users = [
            User(
                user_id=uuid.uuid4(),
                email="admin@fleet.com",
                password_hash=hash_password("admin123"),
                role=UserRole.admin,
                name="Admin User",
                phone="+1-555-0001"
            ),
            User(
                user_id=uuid.uuid4(),
                email="operator@fleet.com",
                password_hash=hash_password("operator123"),
                role=UserRole.operator,
                name="Fleet Operator",
                phone="+1-555-0002"
            ),
            User(
                user_id=uuid.uuid4(),
                email="driver1@fleet.com",
                password_hash=hash_password("driver123"),
                role=UserRole.driver,
                name="John Driver",
                phone="+1-555-0003"
            ),
        ]
        
        for user in users:
            session.add(user)
        
        await session.commit()
        print(f"✅ Seeded {len(users)} users")


async def seed_drivers():
    """Seed drivers"""
    async with AsyncSessionLocal() as session:
        # Check if drivers already exist
        result = await session.execute(text("SELECT COUNT(*) FROM drivers"))
        count = result.scalar()
        if count > 0:
            print("✅ Drivers already seeded")
            return
        
        # Get driver user
        result = await session.execute(
            text("SELECT user_id FROM users WHERE role = 'driver'")
        )
        driver_user_ids = [row[0] for row in result.fetchall()]
        
        drivers = [
            Driver(
                driver_id=uuid.uuid4(),
                user_id=driver_user_ids[0] if driver_user_ids else None,
                name="John Driver",
                phone="+1-555-1001",
                license_number="DL123456"
            ),
            Driver(
                driver_id=uuid.uuid4(),
                name="Jane Transporter",
                phone="+1-555-1002",
                license_number="DL123457"
            ),
            Driver(
                driver_id=uuid.uuid4(),
                name="Mike Hauler",
                phone="+1-555-1003",
                license_number="DL123458"
            ),
        ]
        
        for driver in drivers:
            session.add(driver)
        
        await session.commit()
        print(f"✅ Seeded {len(drivers)} drivers")


async def seed_vehicles():
    """Seed vehicles"""
    async with AsyncSessionLocal() as session:
        # Check if vehicles already exist
        result = await session.execute(text("SELECT COUNT(*) FROM vehicles"))
        count = result.scalar()
        if count > 0:
            print("✅ Vehicles already seeded")
            return
        
        # Get some driver IDs
        result = await session.execute(text("SELECT driver_id FROM drivers LIMIT 3"))
        driver_ids = [row[0] for row in result.fetchall()]
        
        vehicles = [
            Vehicle(
                vehicle_id="VEH-001",
                plate_number="TXA-1234",
                make="Ford",
                model="F-150",
                year=2022,
                status=VehicleStatus.active,
                last_service_date=datetime.utcnow() - timedelta(days=30),
                next_service_due=datetime.utcnow() + timedelta(days=60),
                odometer_km=15234.5,
                assigned_driver_id=driver_ids[0] if driver_ids else None,
                region="North"
            ),
            Vehicle(
                vehicle_id="VEH-002",
                plate_number="TXA-5678",
                make="Chevrolet",
                model="Silverado",
                year=2023,
                status=VehicleStatus.active,
                last_service_date=datetime.utcnow() - timedelta(days=45),
                next_service_due=datetime.utcnow() + timedelta(days=45),
                odometer_km=8942.3,
                assigned_driver_id=driver_ids[1] if len(driver_ids) > 1 else None,
                region="South"
            ),
            Vehicle(
                vehicle_id="VEH-003",
                plate_number="TXA-9012",
                make="RAM",
                model="1500",
                year=2021,
                status=VehicleStatus.active,
                last_service_date=datetime.utcnow() - timedelta(days=60),
                next_service_due=datetime.utcnow() + timedelta(days=30),
                odometer_km=25678.9,
                assigned_driver_id=driver_ids[2] if len(driver_ids) > 2 else None,
                region="East"
            ),
            Vehicle(
                vehicle_id="VEH-004",
                plate_number="TXA-3456",
                make="Toyota",
                model="Tundra",
                year=2022,
                status=VehicleStatus.active,
                last_service_date=datetime.utcnow() - timedelta(days=20),
                next_service_due=datetime.utcnow() + timedelta(days=70),
                odometer_km=12045.2,
                region="West"
            ),
            Vehicle(
                vehicle_id="VEH-005",
                plate_number="TXA-7890",
                make="Ford",
                model="Transit",
                year=2023,
                status=VehicleStatus.maintenance,
                last_service_date=datetime.utcnow() - timedelta(days=2),
                next_service_due=datetime.utcnow() + timedelta(days=88),
                odometer_km=5432.1,
                region="North"
            ),
            Vehicle(
                vehicle_id="VEH-006",
                plate_number="TXA-2468",
                make="Mercedes",
                model="Sprinter",
                year=2022,
                status=VehicleStatus.active,
                last_service_date=datetime.utcnow() - timedelta(days=35),
                next_service_due=datetime.utcnow() + timedelta(days=55),
                odometer_km=18234.7,
                region="South"
            ),
            Vehicle(
                vehicle_id="VEH-007",
                plate_number="TXA-1357",
                make="Nissan",
                model="Titan",
                year=2021,
                status=VehicleStatus.active,
                last_service_date=datetime.utcnow() - timedelta(days=50),
                next_service_due=datetime.utcnow() + timedelta(days=40),
                odometer_km=32156.4,
                region="East"
            ),
            Vehicle(
                vehicle_id="VEH-008",
                plate_number="TXA-2469",
                make="GMC",
                model="Sierra",
                year=2023,
                status=VehicleStatus.offline,
                last_service_date=datetime.utcnow() - timedelta(days=10),
                next_service_due=datetime.utcnow() + timedelta(days=80),
                odometer_km=3421.8,
                region="West"
            ),
            Vehicle(
                vehicle_id="VEH-009",
                plate_number="TXA-9753",
                make="Ford",
                model="Ranger",
                year=2022,
                status=VehicleStatus.active,
                last_service_date=datetime.utcnow() - timedelta(days=25),
                next_service_due=datetime.utcnow() + timedelta(days=65),
                odometer_km=14532.6,
                region="North"
            ),
            Vehicle(
                vehicle_id="VEH-010",
                plate_number="TXA-8642",
                make="Chevrolet",
                model="Colorado",
                year=2021,
                status=VehicleStatus.active,
                last_service_date=datetime.utcnow() - timedelta(days=40),
                next_service_due=datetime.utcnow() + timedelta(days=50),
                odometer_km=21098.3,
                region="South"
            ),
        ]
        
        for vehicle in vehicles:
            session.add(vehicle)
        
        await session.commit()
        print(f"✅ Seeded {len(vehicles)} vehicles")


async def seed_alert_rules():
    """Seed alert rules"""
    async with AsyncSessionLocal() as session:
        # Check if alert rules already exist
        result = await session.execute(text("SELECT COUNT(*) FROM alert_rules"))
        count = result.scalar()
        if count > 0:
            print("✅ Alert rules already seeded")
            return
        
        rules_sql = """
        INSERT INTO alert_rules (rule_id, name, description, condition, severity, actions, enabled)
        VALUES
        (uuid_generate_v4(), 'Speeding - Urban', 'Speed exceeds urban limit by 15+ km/h', 
         '{"type": "speeding", "context": "urban", "threshold": 15}'::jsonb, 
         'MEDIUM', '{"notify": ["driver", "operator"], "channels": ["email", "app"]}'::jsonb, true),
        
        (uuid_generate_v4(), 'Speeding - Highway', 'Speed exceeds highway limit by 30+ km/h', 
         '{"type": "speeding", "context": "highway", "threshold": 30}'::jsonb, 
         'HIGH', '{"notify": ["driver", "operator", "manager"], "channels": ["sms", "app"]}'::jsonb, true),
        
        (uuid_generate_v4(), 'Excess Idle', 'Vehicle idle for 30+ minutes', 
         '{"type": "idle", "threshold_minutes": 30}'::jsonb, 
         'HIGH', '{"notify": ["driver", "dispatcher"], "channels": ["app"]}'::jsonb, true),
        
        (uuid_generate_v4(), 'Route Deviation', 'Vehicle off-route by 1+ km', 
         '{"type": "geofence", "threshold_meters": 1000}'::jsonb, 
         'HIGH', '{"notify": ["driver", "operator"], "channels": ["app", "sms"]}'::jsonb, true),
        
        (uuid_generate_v4(), 'Maintenance Due', 'Vehicle due for maintenance within 7 days', 
         '{"type": "maintenance", "threshold_days": 7}'::jsonb, 
         'MEDIUM', '{"notify": ["operator", "maintenance"], "channels": ["email"]}'::jsonb, true),
        
        (uuid_generate_v4(), 'Connectivity Lost', 'No telemetry for 30+ minutes', 
         '{"type": "connectivity", "threshold_minutes": 30}'::jsonb, 
         'HIGH', '{"notify": ["operator"], "channels": ["email", "sms"]}'::jsonb, true);
        """
        
        await session.execute(text(rules_sql))
        await session.commit()
        print("✅ Seeded alert rules")


async def main():
    """Main seed function"""
    print("🌱 Starting database seeding...")
    
    try:
        await seed_users()
        await seed_drivers()
        await seed_vehicles()
        await seed_alert_rules()
        
        print("\n✅ Database seeding complete!")
        print("\n📝 Login credentials:")
        print("   Admin: admin@fleet.com / admin123")
        print("   Operator: operator@fleet.com / operator123")
        print("   Driver: driver1@fleet.com / driver123")
        
    except Exception as e:
        print(f"❌ Error seeding database: {e}")
        raise


if __name__ == "__main__":
    asyncio.run(main())

