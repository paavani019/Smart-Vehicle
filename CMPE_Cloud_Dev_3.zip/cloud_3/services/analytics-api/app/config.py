"""Configuration settings for Analytics API"""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings"""
    
    DATABASE_URL: str = "postgresql://postgres:postgres@localhost:5432/fleet_db"
    TIMESCALE_URL: str = "postgresql://postgres:postgres@localhost:5433/telemetry_db"
    
    MINIO_ENDPOINT: str = "localhost:9000"
    MINIO_ACCESS_KEY: str = "minioadmin"
    MINIO_SECRET_KEY: str = "minioadmin"
    MINIO_BUCKET: str = "reports"
    MINIO_SECURE: bool = False
    
    JWT_SECRET: str = "dev-secret-change-in-production"
    JWT_ALGORITHM: str = "HS256"
    
    class Config:
        env_file = ".env"


settings = Settings()

