import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { api } from '@/lib/api'
import { Wrench, AlertTriangle } from 'lucide-react'

export function Maintenance() {
  const { data: maintenanceAlerts, isLoading } = useQuery({
    queryKey: ['maintenance-alerts'],
    queryFn: () => api.getMaintenanceAlerts().then(res => res.data),
  })

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    )
  }

  const alerts = maintenanceAlerts || []

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Maintenance</h1>
        <p className="text-muted-foreground mt-1">
          Predictive maintenance and service scheduling
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Due Soon</p>
                <p className="text-3xl font-bold mt-2">
                  {alerts.filter((a: any) => a.severity === 'Medium').length}
                </p>
              </div>
              <div className="bg-yellow-50 p-3 rounded-lg">
                <AlertTriangle className="h-6 w-6 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Critical</p>
                <p className="text-3xl font-bold mt-2">
                  {alerts.filter((a: any) => a.severity === 'Critical').length}
                </p>
              </div>
              <div className="bg-red-50 p-3 rounded-lg">
                <AlertTriangle className="h-6 w-6 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">In Service</p>
                <p className="text-3xl font-bold mt-2">1</p>
              </div>
              <div className="bg-blue-50 p-3 rounded-lg">
                <Wrench className="h-6 w-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Maintenance Queue</CardTitle>
        </CardHeader>
        <CardContent>
          {alerts.length > 0 ? (
            <div className="space-y-3">
              {alerts.map((alert: any) => (
                <div
                  key={alert.id}
                  className="flex items-start justify-between p-4 border rounded-lg"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <span
                        className={`px-2 py-1 text-xs font-medium rounded ${
                          alert.severity === 'Critical'
                            ? 'bg-red-100 text-red-700'
                            : alert.severity === 'High'
                            ? 'bg-orange-100 text-orange-700'
                            : 'bg-yellow-100 text-yellow-700'
                        }`}
                      >
                        {alert.severity}
                      </span>
                      <span className="text-sm font-medium">{alert.vehicle_id}</span>
                      <span className="text-sm text-muted-foreground">
                        {alert.component}
                      </span>
                    </div>
                    <p className="font-medium mb-1">{alert.predicted_issue}</p>
                    <p className="text-sm text-muted-foreground">
                      {alert.recommended_action}
                    </p>
                    {alert.due_date && (
                      <p className="text-sm text-muted-foreground mt-1">
                        Due: {alert.due_date}
                      </p>
                    )}
                  </div>
                  <div className="ml-4">
                    <span className="text-sm font-medium text-primary">
                      {(alert.confidence * 100).toFixed(0)}% confidence
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">
              No maintenance scheduled
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

