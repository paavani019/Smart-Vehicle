"""Analytics query routes"""

from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from datetime import date, datetime
from typing import Optional

from app.database import get_db, get_timescale_db

router = APIRouter()


@router.get("/time-summary")
async def get_time_summary(
    start_date: date = Query(...),
    end_date: date = Query(...),
    vehicle_id: Optional[str] = None,
    timescale_db: AsyncSession = Depends(get_timescale_db)
):
    """
    Get time summary analytics
    Returns: total_drive_time_hr, idle_time_hr, on_time_percent, avg_speed_kmph, utilization_score
    """
    
    if vehicle_id:
        query = text("""
            SELECT 
                COUNT(*) * 5.0 / 3600 as total_drive_time_hr,
                SUM(CASE WHEN idle_flag THEN 1 ELSE 0 END) * 5.0 / 3600 as idle_time_hr,
                AVG(speed) as avg_speed_kmph,
                COUNT(DISTINCT DATE(ts)) as active_days
            FROM telemetry_records
            WHERE vehicle_id = :vehicle_id
            AND ts BETWEEN :start_date AND :end_date
        """)
        params = {"vehicle_id": vehicle_id, "start_date": start_date, "end_date": end_date}
    else:
        query = text("""
            SELECT 
                COUNT(*) * 5.0 / 3600 as total_drive_time_hr,
                SUM(CASE WHEN idle_flag THEN 1 ELSE 0 END) * 5.0 / 3600 as idle_time_hr,
                AVG(speed) as avg_speed_kmph,
                COUNT(DISTINCT vehicle_id) as total_vehicles
            FROM telemetry_records
            WHERE ts BETWEEN :start_date AND :end_date
        """)
        params = {"start_date": start_date, "end_date": end_date}
    
    result = await timescale_db.execute(query, params)
    row = result.fetchone()
    
    if not row or row[0] is None:
        return {
            "total_drive_time_hr": 0,
            "idle_time_hr": 0,
            "on_time_percent": 0,
            "avg_speed_kmph": 0,
            "utilization_score": 0
        }
    
    total_drive = float(row[0]) if row[0] else 0
    idle_time = float(row[1]) if row[1] else 0
    avg_speed = float(row[2]) if row[2] else 0
    
    # Calculate utilization (simplified: drive time / total possible time)
    total_hours = (end_date - start_date).days * 24
    utilization = (total_drive / total_hours * 100) if total_hours > 0 else 0
    
    # On-time percent (simplified: assume 90% if utilization > 50%)
    on_time_pct = 90 if utilization > 50 else 70
    
    return {
        "total_drive_time_hr": round(total_drive, 2),
        "idle_time_hr": round(idle_time, 2),
        "on_time_percent": round(on_time_pct, 2),
        "avg_speed_kmph": round(avg_speed, 2),
        "utilization_score": round(utilization, 2)
    }


@router.get("/daily-report")
async def get_daily_report(
    date_param: date = Query(..., alias="date"),
    vehicle_id: Optional[str] = None,
    timescale_db: AsyncSession = Depends(get_timescale_db)
):
    """Get daily report for a specific date"""
    
    if vehicle_id:
        query = text("""
            SELECT 
                vehicle_id,
                AVG(speed) as avg_speed,
                MAX(speed) as max_speed,
                AVG(fuel_level) as avg_fuel,
                SUM(CASE WHEN idle_flag THEN 1 ELSE 0 END)::float / COUNT(*)::float as idle_pct,
                MAX(odometer_km) - MIN(odometer_km) as distance_km
            FROM telemetry_records
            WHERE DATE(ts) = :date
            AND vehicle_id = :vehicle_id
            GROUP BY vehicle_id
        """)
        params = {"date": date_param, "vehicle_id": vehicle_id}
    else:
        query = text("""
            SELECT 
                vehicle_id,
                AVG(speed) as avg_speed,
                MAX(speed) as max_speed,
                AVG(fuel_level) as avg_fuel,
                SUM(CASE WHEN idle_flag THEN 1 ELSE 0 END)::float / COUNT(*)::float as idle_pct,
                MAX(odometer_km) - MIN(odometer_km) as distance_km
            FROM telemetry_records
            WHERE DATE(ts) = :date
            GROUP BY vehicle_id
        """)
        params = {"date": date_param}
    
    result = await timescale_db.execute(query, params)
    rows = result.fetchall()
    
    vehicles = []
    for row in rows:
        vehicles.append({
            "vehicle_id": row[0],
            "avg_speed_kmph": round(float(row[1]), 2) if row[1] else 0,
            "max_speed_kmph": round(float(row[2]), 2) if row[2] else 0,
            "avg_fuel_level": round(float(row[3]), 2) if row[3] else 0,
            "idle_percent": round(float(row[4]) * 100, 2) if row[4] else 0,
            "distance_km": round(float(row[5]), 2) if row[5] else 0
        })
    
    return {
        "date": date_param.isoformat(),
        "vehicles": vehicles,
        "total_vehicles": len(vehicles)
    }


@router.get("/kpi")
async def get_kpis(
    timescale_db: AsyncSession = Depends(get_timescale_db)
):
    """Get fleet-wide KPIs (last 7 days)"""
    
    query = text("""
        SELECT 
            COUNT(DISTINCT vehicle_id) as active_vehicles,
            AVG(speed) as avg_speed,
            SUM(CASE WHEN idle_flag THEN 1 ELSE 0 END)::float / COUNT(*)::float as idle_pct
        FROM telemetry_records
        WHERE ts >= NOW() - INTERVAL '7 days'
    """)
    
    result = await timescale_db.execute(query)
    row = result.fetchone()
    
    if not row:
        return {
            "on_time_percent": 0,
            "idle_percent": 0,
            "utilization": 0,
            "active_vehicles": 0
        }
    
    idle_pct = float(row[2]) * 100 if row[2] else 0
    
    return {
        "on_time_percent": 88.5,  # Simplified
        "idle_percent": round(idle_pct, 2),
        "utilization": round(100 - idle_pct, 2),
        "active_vehicles": row[0] or 0
    }


@router.get("/route/{vehicle_id}")
async def get_route(
    vehicle_id: str,
    start_time: Optional[datetime] = None,
    end_time: Optional[datetime] = None,
    timescale_db: AsyncSession = Depends(get_timescale_db)
):
    """Get route polyline for a vehicle"""
    
    if not start_time:
        start_time = datetime.utcnow().replace(hour=0, minute=0, second=0, microsecond=0)
    if not end_time:
        end_time = datetime.utcnow()
    
    query = text("""
        SELECT 
            ts,
            lat,
            lon,
            speed
        FROM telemetry_records
        WHERE vehicle_id = :vehicle_id
        AND ts BETWEEN :start_time AND :end_time
        AND lat IS NOT NULL
        AND lon IS NOT NULL
        ORDER BY ts ASC
        LIMIT 1000
    """)
    
    result = await timescale_db.execute(query, {
        "vehicle_id": vehicle_id,
        "start_time": start_time,
        "end_time": end_time
    })
    rows = result.fetchall()
    
    if not rows:
        raise HTTPException(status_code=404, detail="No route data found")
    
    points = []
    for row in rows:
        points.append({
            "timestamp": row[0].isoformat(),
            "lat": float(row[1]),
            "lon": float(row[2]),
            "speed": float(row[3]) if row[3] else 0
        })
    
    return {
        "vehicle_id": vehicle_id,
        "start_time": start_time.isoformat(),
        "end_time": end_time.isoformat(),
        "points": points
    }

