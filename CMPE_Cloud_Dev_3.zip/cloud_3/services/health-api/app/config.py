"""Configuration settings for Health API"""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings"""
    
    # Database
    DATABASE_URL: str = "postgresql://postgres:postgres@localhost:5432/fleet_db"
    TIMESCALE_URL: str = "postgresql://postgres:postgres@localhost:5433/telemetry_db"
    
    # Redis
    REDIS_URL: str = "redis://localhost:6379"
    
    # Auth
    JWT_SECRET: str = "dev-secret-change-in-production"
    JWT_ALGORITHM: str = "HS256"
    
    # ML Model settings
    MODEL_PATH: str = "/app/models"
    MODEL_RETRAIN_INTERVAL_HOURS: int = 24
    
    # Health score thresholds
    HEALTH_SCORE_CRITICAL: float = 30.0
    HEALTH_SCORE_WARNING: float = 60.0
    HEALTH_SCORE_GOOD: float = 80.0
    
    class Config:
        env_file = ".env"


settings = Settings()

