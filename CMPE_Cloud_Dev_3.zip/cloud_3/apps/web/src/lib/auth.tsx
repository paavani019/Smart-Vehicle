import { createContext, useContext, useState, ReactNode } from 'react'
import { api } from './api'

interface AuthState {
  isAuthenticated: boolean
  user: any | null
  token: string | null
}

interface AuthContextType extends AuthState {
  login: (email: string, password: string) => Promise<{ success: boolean; error?: string }>
  logout: () => void
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [authState, setAuthState] = useState<AuthState>({
    isAuthenticated: !!localStorage.getItem('auth_token'),
    user: JSON.parse(localStorage.getItem('auth_user') || 'null'),
    token: localStorage.getItem('auth_token'),
  })

  const login = async (email: string, password: string) => {
    try {
      const response = await api.login(email, password)
      const { access_token, role, user_id } = response.data

      localStorage.setItem('auth_token', access_token)
      localStorage.setItem('auth_user', JSON.stringify({ role, user_id, email }))

      setAuthState({
        isAuthenticated: true,
        user: { role, user_id, email },
        token: access_token,
      })

      return { success: true }
    } catch (error: any) {
      return {
        success: false,
        error: error.response?.data?.detail || 'Login failed',
      }
    }
  }

  const logout = () => {
    localStorage.removeItem('auth_token')
    localStorage.removeItem('auth_user')
    setAuthState({
      isAuthenticated: false,
      user: null,
      token: null,
    })
  }

  return (
    <AuthContext.Provider value={{ ...authState, login, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

