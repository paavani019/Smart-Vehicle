import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:3001';

const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

export const fetchKPIs = async () => {
  const response = await api.get('/analytics/kpi');
  return response.data;
};

export const fetchTelemetry = async () => {
  const response = await api.get('/telemetry/latest');
  return response.data;
};

export const fetchAlerts = async () => {
  const response = await api.get('/alerts');
  return response.data;
};

export const fetchVehicle = async (id) => {
  const response = await api.get(`/vehicles/${id}`);
  return response.data;
};

export const fetchDailyReport = async () => {
  const response = await api.get('/reports/daily');
  return response.data;
};

export default api;

