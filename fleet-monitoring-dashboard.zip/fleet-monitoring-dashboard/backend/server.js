import express from 'express';
import cors from 'cors';

const app = express();
const PORT = 3001;

app.use(cors());
app.use(express.json());

// Mock vehicle data
const vehicles = [
  { id: 'V001', name: 'Fleet Car Alpha', status: 'active', lat: 40.7128, lng: -74.0060, speed: 45, fuel: 75, onTime: true },
  { id: 'V002', name: 'Fleet Car Beta', status: 'idle', lat: 40.7580, lng: -73.9855, speed: 0, fuel: 60, onTime: true },
  { id: 'V003', name: 'Fleet Car Gamma', status: 'active', lat: 40.7505, lng: -73.9934, speed: 35, fuel: 45, onTime: false },
  { id: 'V004', name: 'Fleet Car Delta', status: 'maintenance', lat: 40.7282, lng: -73.9942, speed: 0, fuel: 30, onTime: true },
  { id: 'V005', name: 'Fleet Car Epsilon', status: 'active', lat: 40.7614, lng: -73.9776, speed: 55, fuel: 80, onTime: true },
];

// Mock alerts
const alerts = [
  { id: 'A001', vehicleId: 'V003', type: 'speeding', severity: 'high', message: 'Vehicle V003 exceeding speed limit', timestamp: new Date(Date.now() - 300000) },
  { id: 'A002', vehicleId: 'V002', type: 'idle', severity: 'medium', message: 'Vehicle V002 idle for 25 minutes', timestamp: new Date(Date.now() - 1500000) },
  { id: 'A003', vehicleId: 'V004', type: 'maintenance', severity: 'high', message: 'Vehicle V004 requires immediate maintenance', timestamp: new Date(Date.now() - 600000) },
  { id: 'A004', vehicleId: 'V001', type: 'fuel', severity: 'low', message: 'Vehicle V001 fuel level below 20%', timestamp: new Date(Date.now() - 120000) },
];

// GET /analytics/kpi
app.get('/analytics/kpi', (req, res) => {
  const activeVehicles = vehicles.filter(v => v.status === 'active').length;
  const onTimeVehicles = vehicles.filter(v => v.onTime).length;
  const onTimePercentage = (onTimeVehicles / vehicles.length) * 100;
  
  // Calculate total idle hours (mock calculation)
  const idleHours = vehicles
    .filter(v => v.status === 'idle')
    .reduce((sum, v) => sum + 0.5, 0); // Mock: 0.5 hours per idle vehicle
  
  const openAlerts = alerts.filter(a => a.severity === 'high' || a.severity === 'medium').length;

  res.json({
    onTimePercentage: Math.round(onTimePercentage),
    idleHours: Math.round(idleHours * 10) / 10,
    activeVehicles,
    openAlerts,
  });
});

// GET /telemetry/latest
app.get('/telemetry/latest', (req, res) => {
  res.json(vehicles.map(v => ({
    id: v.id,
    name: v.name,
    status: v.status,
    location: { lat: v.lat, lng: v.lng },
    speed: v.speed,
    fuel: v.fuel,
    onTime: v.onTime,
    lastUpdate: new Date().toISOString(),
  })));
});

// GET /alerts
app.get('/alerts', (req, res) => {
  res.json(alerts.map(a => ({
    ...a,
    vehicleName: vehicles.find(v => v.id === a.vehicleId)?.name || 'Unknown',
  })));
});

// GET /vehicles/:id
app.get('/vehicles/:id', (req, res) => {
  const vehicle = vehicles.find(v => v.id === req.params.id);
  if (!vehicle) {
    return res.status(404).json({ error: 'Vehicle not found' });
  }

  // Generate mock telemetry history (last 24 hours)
  const telemetryHistory = [];
  const now = Date.now();
  for (let i = 23; i >= 0; i--) {
    const timestamp = new Date(now - i * 3600000);
    telemetryHistory.push({
      timestamp: timestamp.toISOString(),
      speed: Math.max(0, vehicle.speed + (Math.random() - 0.5) * 20),
      fuel: Math.max(0, Math.min(100, vehicle.fuel - i * 0.5 + (Math.random() - 0.5) * 5)),
    });
  }

  // Mock route history
  const routeHistory = [];
  const baseLat = vehicle.lat;
  const baseLng = vehicle.lng;
  for (let i = 0; i < 10; i++) {
    routeHistory.push({
      lat: baseLat + (Math.random() - 0.5) * 0.1,
      lng: baseLng + (Math.random() - 0.5) * 0.1,
      timestamp: new Date(now - (10 - i) * 600000).toISOString(),
    });
  }

  res.json({
    ...vehicle,
    telemetryHistory,
    routeHistory,
    maintenance: {
      lastService: '2024-01-15',
      nextService: '2024-04-15',
      healthScore: Math.floor(70 + Math.random() * 30),
      components: [
        { name: 'Engine', status: 'good', condition: 85 },
        { name: 'Brakes', status: 'good', condition: 90 },
        { name: 'Tires', status: 'fair', condition: 70 },
        { name: 'Battery', status: 'good', condition: 80 },
      ],
    },
  });
});

// GET /reports/daily
app.get('/reports/daily', (req, res) => {
  const today = new Date().toISOString().split('T')[0];
  res.json({
    date: today,
    summary: {
      totalVehicles: vehicles.length,
      activeVehicles: vehicles.filter(v => v.status === 'active').length,
      totalDistance: 1250.5, // km
      totalFuelConsumed: 245.8, // liters
      averageSpeed: 42.5, // km/h
      alertsGenerated: alerts.length,
      maintenanceEvents: 1,
    },
    vehicles: vehicles.map(v => ({
      id: v.id,
      name: v.name,
      status: v.status,
      distance: Math.random() * 200 + 50,
      fuelConsumed: Math.random() * 50 + 10,
      alerts: alerts.filter(a => a.vehicleId === v.id).length,
    })),
  });
});

app.listen(PORT, () => {
  console.log(`Mock API server running on http://localhost:${PORT}`);
});

