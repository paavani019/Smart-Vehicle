# Quick Start Guide

Get the Smart Vehicle Cloud platform running in under 5 minutes!

## Prerequisites

- Docker & Docker Compose (v2.0+)
- Make (optional but recommended)
- 8GB+ RAM available
- Ports available: 5173, 8001-8004, 5432-5433, 6379, 9000-9001, 9090, 3000, 8080

## Step 1: Clone & Start

```bash
# Start all services
make up

# This will start:
# - PostgreSQL + TimescaleDB
# - Kafka (Redpanda)
# - Redis
# - MinIO
# - 4 FastAPI services
# - 2 Workers
# - React frontend
# - Prometheus + Grafana
```

## Step 2: Seed Database

```bash
# Seed with sample vehicles, users, and alert rules
make seed
```

This creates:
- 3 users (admin, operator, driver)
- 10 vehicles with different statuses
- 6 alert rules
- Initial configuration

## Step 3: Start Simulator

```bash
# Generate live vehicle telemetry
make simulate
```

The simulator will:
- Generate telemetry for 9 active vehicles
- Send data every 5 seconds
- Simulate realistic driving patterns
- Trigger various alerts

## Step 4: Access Dashboard

Open your browser to:

**http://localhost:5173**

Login with:
- **Email**: `admin@fleet.com`
- **Password**: `admin123`

## Step 5: Explore

### Overview Page
- View fleet KPIs (On-time %, Idle %, Active vehicles)
- See recent alerts
- Check maintenance due list

### Vehicles Page
- Browse all vehicles
- See status and assigned drivers
- View last known location

### Alerts Center
- Filter by severity (HIGH, MEDIUM, LOW)
- Acknowledge and resolve alerts
- View alert details and context

### Reports Page
- Generate daily/weekly reports
- Download utilization reports
- View driver scorecards

### Maintenance Page
- View predictive maintenance alerts
- See maintenance queue
- Check vehicle health scores

## Common Commands

```bash
# View logs
make logs

# View logs for specific service
make logs-ingestion

# Stop everything
make down

# Reset and restart
make down-v
make up
make seed

# Run tests
make test

# Check service health
docker-compose ps
```

## API Documentation

Access Swagger/OpenAPI docs:

- **Ingestion API**: http://localhost:8001/docs
- **Health API**: http://localhost:8002/docs
- **Analytics API**: http://localhost:8003/docs
- **Alerts API**: http://localhost:8004/docs

## Observability Dashboards

- **Grafana**: http://localhost:3000 (admin/admin)
- **Prometheus**: http://localhost:9090
- **Kafka UI**: http://localhost:8080
- **MinIO Console**: http://localhost:9001 (minioadmin/minioadmin)

## Troubleshooting

### Services won't start
```bash
# Check Docker resources
docker system df

# Free up space
docker system prune -a

# Check ports
lsof -i :5173
```

### Simulator fails to send data
```bash
# Check if services are healthy
docker-compose ps

# Check ingestion API logs
make logs-ingestion

# Restart ingestion API
docker-compose restart ingestion-api
```

### Database connection errors
```bash
# Wait for databases to be ready
docker-compose logs postgres timescaledb

# Reset databases
make db-reset
```

### No data showing in dashboard
```bash
# Ensure simulator is running
make simulate

# Check Kafka messages
docker-compose exec kafka rpk topic consume telemetry.raw --num 10

# Check TimescaleDB
make shell-timescale
# Then: SELECT COUNT(*) FROM telemetry_records;
```

## Next Steps

1. **Explore Alert Rules**: Check `/docs/ALERT_RULES.md`
2. **Review Architecture**: See `/docs/ARCHITECTURE.md`
3. **Customize Configuration**: Copy `.env.example` to `.env` and modify
4. **Add Real Data**: Integrate with your vehicle data sources
5. **Deploy to Production**: See Kubernetes deployment docs

## Support

- Documentation: `/docs`
- Issues: GitHub Issues
- Architecture: `/docs/ARCHITECTURE.md`
- Alert Rules: `/docs/ALERT_RULES.md`

---

**Happy Monitoring! 🚗📊**

