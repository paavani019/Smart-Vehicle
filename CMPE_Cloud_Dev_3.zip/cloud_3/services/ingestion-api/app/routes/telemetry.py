"""Telemetry ingestion routes"""

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, text
from datetime import datetime
import redis.asyncio as redis
import json
import logging

from app.database import get_db, get_timescale_db
from app.models import Vehicle
from app.schemas import (
    TelemetryBatchRequest,
    TelemetryBatchResponse,
    LatestTelemetry
)
from app.routes.auth import get_current_user
from app.kafka_client import kafka_client
from app.config import settings

router = APIRouter()
logger = logging.getLogger(__name__)


# Redis client for caching
redis_client: redis.Redis | None = None


async def get_redis():
    """Get Redis client"""
    global redis_client
    if redis_client is None:
        redis_client = redis.from_url(settings.REDIS_URL)
    return redis_client


def validate_telemetry_record(record: dict) -> tuple[bool, list[str]]:
    """Validate telemetry record and return (is_valid, errors)"""
    errors = []
    
    # Check timestamp drift
    try:
        ts = datetime.fromisoformat(record["ts"].replace("Z", "+00:00"))
        drift_ms = abs((datetime.utcnow() - ts).total_seconds() * 1000)
        if drift_ms > settings.MAX_TIMESTAMP_DRIFT_MS:
            errors.append(f"TIMESTAMP_DRIFT: {drift_ms}ms")
    except Exception as e:
        errors.append(f"INVALID_TIMESTAMP: {str(e)}")
    
    # Check required fields
    if "vehicleId" not in record:
        errors.append("MISSING_VEHICLE_ID")
    
    # Check GPS bounds if provided
    if "gps" in record and record["gps"]:
        lat, lon = record["gps"]
        if abs(lat) > 90 or abs(lon) > 180:
            errors.append("INVALID_GPS_COORDINATES")
    
    # Check value ranges
    if "speed" in record and record["speed"]:
        if record["speed"] < 0 or record["speed"] > 300:
            errors.append("INVALID_SPEED")
    
    if "rpm" in record and record["rpm"]:
        if record["rpm"] < 0 or record["rpm"] > 10000:
            errors.append("INVALID_RPM")
    
    if "batteryVoltage" in record and record["batteryVoltage"]:
        if record["batteryVoltage"] < 0 or record["batteryVoltage"] > 20:
            errors.append("INVALID_BATTERY_VOLTAGE")
    
    return len(errors) == 0, errors


@router.post("/batch", response_model=TelemetryBatchResponse)
async def ingest_telemetry_batch(
    request: TelemetryBatchRequest,
    current_user = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Push CAN/GNSS/IMU batch telemetry data
    Validates, publishes to Kafka, returns 202 with offsets
    """
    
    accepted = 0
    rejected = 0
    offsets = []
    errors = []
    
    for record in request.records:
        record_dict = record.model_dump()
        
        # Validate record
        is_valid, validation_errors = validate_telemetry_record(record_dict)
        
        if not is_valid:
            rejected += 1
            errors.append({
                "vehicleId": record_dict.get("vehicleId"),
                "errors": validation_errors
            })
            continue
        
        # Publish to Kafka
        try:
            offset = await kafka_client.publish(
                topic=settings.KAFKA_TOPIC_RAW,
                message=record_dict,
                key=record_dict["vehicleId"]
            )
            offsets.append(offset if offset else -1)
            accepted += 1
            
            # Update Redis cache with latest telemetry
            redis_conn = await get_redis()
            await redis_conn.setex(
                f"telemetry:latest:{record_dict['vehicleId']}",
                300,  # 5 min TTL
                json.dumps(record_dict)
            )
            
        except Exception as e:
            logger.error(f"Failed to publish telemetry: {e}")
            rejected += 1
            errors.append({
                "vehicleId": record_dict.get("vehicleId"),
                "errors": [f"KAFKA_ERROR: {str(e)}"]
            })
    
    return TelemetryBatchResponse(
        status="PARTIAL" if rejected > 0 else "SUCCESS",
        accepted=accepted,
        rejected=rejected,
        kafka_offsets=offsets if accepted > 0 else None,
        errors=errors if errors else None
    )


@router.get("/latest", response_model=list[LatestTelemetry])
async def get_latest_telemetry(
    current_user = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get latest telemetry snapshot for all active vehicles (cached in Redis)"""
    
    # Get all active vehicles
    result = await db.execute(
        select(Vehicle).where(Vehicle.status == "active")
    )
    vehicles = result.scalars().all()
    
    latest_telemetry = []
    redis_conn = await get_redis()
    
    for vehicle in vehicles:
        try:
            cached = await redis_conn.get(f"telemetry:latest:{vehicle.vehicle_id}")
            if cached:
                data = json.loads(cached)
                latest_telemetry.append(
                    LatestTelemetry(
                        vehicleId=vehicle.vehicle_id,
                        timestamp=datetime.fromisoformat(data["ts"].replace("Z", "+00:00")),
                        location={
                            "lat": data["gps"][0],
                            "lon": data["gps"][1]
                        } if "gps" in data and data["gps"] else None,
                        speed=data.get("speed"),
                        status=vehicle.status.value
                    )
                )
        except Exception as e:
            logger.warning(f"Failed to get cached telemetry for {vehicle.vehicle_id}: {e}")
            continue
    
    return latest_telemetry


@router.get("/latest/{vehicle_id}")
async def get_vehicle_latest_telemetry(
    vehicle_id: str,
    current_user = Depends(get_current_user),
    timescale_db: AsyncSession = Depends(get_timescale_db)
):
    """Get latest telemetry for a specific vehicle from TimescaleDB"""
    
    query = text("""
        SELECT 
            vehicle_id,
            ts,
            lat,
            lon,
            speed,
            rpm,
            fuel_level,
            engine_status,
            idle_flag,
            coolant_temp,
            battery_voltage,
            odometer_km
        FROM telemetry_records
        WHERE vehicle_id = :vehicle_id
        ORDER BY ts DESC
        LIMIT 1
    """)
    
    result = await timescale_db.execute(query, {"vehicle_id": vehicle_id})
    row = result.fetchone()
    
    if not row:
        raise HTTPException(status_code=404, detail=f"No telemetry found for vehicle {vehicle_id}")
    
    return {
        "vehicleId": row[0],
        "timestamp": row[1],
        "location": {"lat": float(row[2]), "lon": float(row[3])} if row[2] and row[3] else None,
        "speed": float(row[4]) if row[4] else None,
        "rpm": row[5],
        "fuelLevel": float(row[6]) if row[6] else None,
        "engineStatus": row[7],
        "idle": row[8],
        "coolantTemp": float(row[9]) if row[9] else None,
        "batteryVoltage": float(row[10]) if row[10] else None,
        "odometerKm": float(row[11]) if row[11] else None
    }

