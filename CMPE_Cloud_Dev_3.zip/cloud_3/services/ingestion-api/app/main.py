"""
Ingestion API - Smart Vehicle Data Ingestion Service
Handles telemetry upload, validation, and streaming to Kafka
"""

from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from prometheus_client import Counter, Histogram, generate_latest
from contextlib import asynccontextmanager
import logging

from app.config import settings
from app.routes import data, telemetry, auth
from app.database import init_db
from app.kafka_client import kafka_client

# Logging configuration
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Prometheus metrics
REQUEST_COUNT = Counter('ingestion_requests_total', 'Total requests', ['method', 'endpoint'])
REQUEST_LATENCY = Histogram('ingestion_request_latency_seconds', 'Request latency')
VALIDATION_ERRORS = Counter('ingestion_validation_errors_total', 'Validation errors', ['error_type'])


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events"""
    logger.info("Starting Ingestion API...")
    await init_db()
    await kafka_client.start()
    logger.info("✅ Ingestion API ready")
    yield
    logger.info("Shutting down Ingestion API...")
    await kafka_client.stop()


app = FastAPI(
    title="Fleet Ingestion API",
    version="1.0.0",
    description="Smart Vehicle Data Ingestion & Streaming Service",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(auth.router, prefix="/v1/auth", tags=["Authentication"])
app.include_router(data.router, prefix="/v1/data", tags=["Data Upload"])
app.include_router(telemetry.router, prefix="/v1/telemetry", tags=["Telemetry"])


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "Ingestion API",
        "version": "1.0.0",
        "status": "running"
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "database": "connected",
        "kafka": "connected" if kafka_client.producer else "disconnected"
    }


@app.get("/metrics")
async def metrics():
    """Prometheus metrics endpoint"""
    return generate_latest()


# WebSocket endpoint for real-time events
class ConnectionManager:
    def __init__(self):
        self.active_connections: list[WebSocket] = []

    async def connect(self, websocket: WebSocket):
        await websocket.accept()
        self.active_connections.append(websocket)

    def disconnect(self, websocket: WebSocket):
        self.active_connections.remove(websocket)

    async def broadcast(self, message: dict):
        for connection in self.active_connections:
            try:
                await connection.send_json(message)
            except Exception:
                pass


manager = ConnectionManager()


@app.websocket("/v1/events")
async def websocket_endpoint(websocket: WebSocket):
    """WebSocket endpoint for streaming ingestion events"""
    await manager.connect(websocket)
    try:
        while True:
            data = await websocket.receive_text()
            # Echo back for now (in production, this would stream from Kafka)
            await manager.broadcast({"type": "ping", "data": data})
    except WebSocketDisconnect:
        manager.disconnect(websocket)

