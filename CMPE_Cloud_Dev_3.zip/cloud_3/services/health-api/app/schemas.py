"""Pydantic schemas for request/response validation"""

from pydantic import BaseModel, Field
from typing import Optional, Dict, List
from datetime import datetime, date
from uuid import UUID


class MaintenancePrediction(BaseModel):
    """Maintenance prediction response"""
    vehicle_id: str
    predicted_issue: str
    confidence: float = Field(..., ge=0, le=1)
    next_service_due: Optional[date] = None
    health_score: float = Field(..., ge=0, le=100)
    severity: str  # Low, Medium, High, Critical
    recommended_action: str


class MaintenanceReportCreate(BaseModel):
    """Create maintenance report"""
    vehicle_id: str
    report_date: date
    cost: Optional[float] = None
    parts_changed: Optional[List[Dict]] = None
    remarks: Optional[str] = None
    performed_by: Optional[str] = None


class MaintenanceReportResponse(BaseModel):
    """Maintenance report response"""
    id: UUID
    vehicle_id: str
    report_date: date
    cost: Optional[float]
    parts_changed: Optional[List[Dict]]
    remarks: Optional[str]
    performed_by: Optional[str]
    created_at: datetime


class HealthScore(BaseModel):
    """Vehicle health score"""
    vehicle_id: str
    health_score: float = Field(..., ge=0, le=100)
    components: Dict[str, float]
    status: str  # Excellent, Good, Fair, Poor, Critical
    last_updated: datetime


class HealthHistory(BaseModel):
    """Health score history"""
    vehicle_id: str
    history: List[Dict]  # [{timestamp, score}]


class MaintenanceAlert(BaseModel):
    """Maintenance alert"""
    id: UUID
    vehicle_id: str
    component: str
    predicted_issue: str
    confidence: float
    severity: str
    due_date: Optional[date]
    recommended_action: str
    created_at: datetime

