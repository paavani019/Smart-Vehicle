"""Configuration settings for Ingestion API"""

from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    """Application settings"""
    
    # Database
    DATABASE_URL: str = "postgresql://postgres:postgres@localhost:5432/fleet_db"
    TIMESCALE_URL: str = "postgresql://postgres:postgres@localhost:5433/telemetry_db"
    
    # Kafka
    KAFKA_BOOTSTRAP_SERVERS: str = "localhost:9092"
    KAFKA_TOPIC_RAW: str = "telemetry.raw"
    KAFKA_TOPIC_PROCESSED: str = "telemetry.processed"
    KAFKA_TOPIC_ALERTS: str = "alerts.events"
    
    # Redis
    REDIS_URL: str = "redis://localhost:6379"
    
    # MinIO
    MINIO_ENDPOINT: str = "localhost:9000"
    MINIO_ACCESS_KEY: str = "minioadmin"
    MINIO_SECRET_KEY: str = "minioadmin"
    MINIO_BUCKET: str = "vehicle-data"
    MINIO_SECURE: bool = False
    
    # Auth
    JWT_SECRET: str = "dev-secret-change-in-production"
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRATION_MINUTES: int = 60
    
    # Rate limiting
    RATE_LIMIT_PER_VEHICLE: int = 60  # requests per minute
    RATE_LIMIT_PER_USER: int = 1000
    
    # Validation
    MAX_BATCH_SIZE_MB: int = 5
    MAX_TIMESTAMP_DRIFT_MS: int = 2000
    
    class Config:
        env_file = ".env"


settings = Settings()

