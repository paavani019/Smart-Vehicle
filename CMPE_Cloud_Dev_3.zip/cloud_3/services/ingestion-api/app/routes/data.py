"""Data upload routes"""

from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from uuid import uuid4
from datetime import datetime
import hashlib

from app.database import get_db
from app.models import IngestionJob, Vehicle
from app.schemas import DataUploadResponse, IngestionJobStatus, VehicleStatusResponse
from app.routes.auth import get_current_user
from app.kafka_client import kafka_client
from app.config import settings

router = APIRouter()


@router.post("/upload", response_model=DataUploadResponse)
async def upload_data(
    vehicle_id: str = Form(...),
    file: UploadFile = File(...),
    current_user = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Upload multi-sensor data batch (camera, LiDAR, radar, GPS, telemetry)
    Accepts multipart file upload, validates, and queues for processing
    """
    
    # Check if vehicle exists
    result = await db.execute(select(Vehicle).where(Vehicle.vehicle_id == vehicle_id))
    vehicle = result.scalar_one_or_none()
    if not vehicle:
        raise HTTPException(status_code=404, detail=f"Vehicle {vehicle_id} not found")
    
    # Read file content
    content = await file.read()
    file_size = len(content)
    
    # Check file size (5MB limit in dev)
    if file_size > settings.MAX_BATCH_SIZE_MB * 1024 * 1024:
        raise HTTPException(
            status_code=400,
            detail=f"File size exceeds {settings.MAX_BATCH_SIZE_MB}MB limit"
        )
    
    # Calculate checksum
    checksum = hashlib.sha256(content).hexdigest()
    
    # Create ingestion job
    job_id = uuid4()
    job = IngestionJob(
        job_id=job_id,
        vehicle_id=vehicle_id,
        status="QUEUED",
        job_type="MULTIPART_UPLOAD",
        file_size_bytes=file_size,
        file_path=f"raw/{vehicle_id}/{job_id}/{file.filename}"
    )
    db.add(job)
    await db.commit()
    
    # In production, upload to MinIO and publish to Kafka
    # For now, just mark as queued
    
    return DataUploadResponse(
        jobId=str(job_id),
        status="QUEUED",
        vehicleId=vehicle_id,
        message=f"File {file.filename} queued for processing"
    )


@router.get("/status/{vehicle_id}", response_model=VehicleStatusResponse)
async def get_vehicle_status(
    vehicle_id: str,
    current_user = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get latest ingestion status for a vehicle"""
    
    # Get pending jobs count
    result = await db.execute(
        select(IngestionJob)
        .where(IngestionJob.vehicle_id == vehicle_id)
        .where(IngestionJob.status.in_(["QUEUED", "PROCESSING"]))
    )
    pending_jobs = result.scalars().all()
    
    # Get recent jobs
    result = await db.execute(
        select(IngestionJob)
        .where(IngestionJob.vehicle_id == vehicle_id)
        .order_by(IngestionJob.created_at.desc())
        .limit(5)
    )
    recent_jobs = result.scalars().all()
    
    recent_status = [
        IngestionJobStatus(
            jobId=str(job.job_id),
            status=job.status,
            vehicleId=job.vehicle_id,
            jobType=job.job_type,
            errors=job.validation_errors.get("errors", []) if job.validation_errors else None,
            createdAt=job.created_at,
            updatedAt=job.updated_at
        )
        for job in recent_jobs
    ]
    
    return VehicleStatusResponse(
        vehicleId=vehicle_id,
        pendingJobs=len(pending_jobs),
        recent=recent_status
    )


@router.get("/jobs/{job_id}", response_model=IngestionJobStatus)
async def get_job_status(
    job_id: str,
    current_user = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get validation details & metrics for a specific job"""
    
    result = await db.execute(
        select(IngestionJob).where(IngestionJob.job_id == job_id)
    )
    job = result.scalar_one_or_none()
    
    if not job:
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found")
    
    return IngestionJobStatus(
        jobId=str(job.job_id),
        status=job.status,
        vehicleId=job.vehicle_id,
        jobType=job.job_type,
        errors=job.validation_errors.get("errors", []) if job.validation_errors else None,
        createdAt=job.created_at,
        updatedAt=job.updated_at
    )

