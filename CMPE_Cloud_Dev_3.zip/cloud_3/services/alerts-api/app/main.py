"""
Alerts API - Rule Engine & Notification Service
Implements context-aware alert rules and notification management
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import logging

from app.config import settings
from app.routes import alerts, notifications
from app.database import init_db
from app.kafka_client import kafka_client

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events"""
    logger.info("Starting Alerts API...")
    await init_db()
    await kafka_client.start()
    logger.info("✅ Alerts API ready")
    yield
    logger.info("Shutting down Alerts API...")
    await kafka_client.stop()


app = FastAPI(
    title="Fleet Alerts API",
    version="1.0.0",
    description="Rule Engine & Notification Service",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(alerts.router, prefix="/v1/alerts", tags=["Alerts"])
app.include_router(notifications.router, prefix="/v1/notifications", tags=["Notifications"])


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "Alerts API",
        "version": "1.0.0",
        "status": "running"
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "database": "connected",
        "kafka": "connected" if kafka_client.producer else "disconnected"
    }

