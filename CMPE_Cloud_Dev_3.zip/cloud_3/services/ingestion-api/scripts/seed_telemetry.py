#!/usr/bin/env python3
"""
Seed historical telemetry data into TimescaleDB
"""

import asyncio
import sys
import random
from pathlib import Path
from datetime import datetime, timedelta

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent.parent))

from sqlalchemy import text
from app.database import TimescaleSessionLocal, AsyncSessionLocal


async def seed_telemetry_data():
    """Seed historical telemetry data for the past 7 days"""
    async with TimescaleSessionLocal() as ts_session:
        print("🔄 Checking existing telemetry data...")
        
        # Check if data already exists
        result = await ts_session.execute(text("SELECT COUNT(*) FROM telemetry_records"))
        count = result.scalar()
        
        if count > 100:
            print(f"✅ Telemetry data already seeded ({count} records)")
            return
        
        print("📊 Generating historical telemetry data for past 7 days...")
        
        # Get vehicle IDs from main PostgreSQL database
        async with AsyncSessionLocal() as pg_session:
            result = await pg_session.execute(text("SELECT vehicle_id FROM vehicles LIMIT 10"))
            vehicle_ids = [row[0] for row in result.fetchall()]
        
        if not vehicle_ids:
            print("❌ No vehicles found. Please run seed.py first.")
            return
        
        # Generate telemetry data for each vehicle
        data_points = []
        now = datetime.utcnow()
        
        for vehicle_id in vehicle_ids:
            # Generate data points every 5 minutes for the past 7 days
            for i in range(2016):  # 7 days * 24 hours * 12 (5-min intervals)
                timestamp = now - timedelta(minutes=5 * i)
                
                # Simulate realistic telemetry
                speed = random.uniform(0, 120)
                lat = 30.2672 + random.uniform(-0.5, 0.5)  # Around Austin, TX
                lon = -97.7431 + random.uniform(-0.5, 0.5)
                fuel = max(5, 100 - (i * 0.05))  # Gradually decreasing fuel
                coolant_temp = random.uniform(80, 105)
                rpm = int(random.uniform(800, 3500) if speed > 0 else random.uniform(700, 900))
                battery = random.uniform(12.0, 14.5)
                idle = speed < 5
                
                data_points.append({
                    "vehicle_id": vehicle_id,
                    "ts": timestamp,
                    "speed": speed,
                    "lat": lat,
                    "lon": lon,
                    "fuel_level": fuel,
                    "coolant_temp": coolant_temp,
                    "rpm": rpm,
                    "battery_voltage": battery,
                    "odometer_km": 15000 + (i * 0.5),
                    "idle_flag": idle,
                    "engine_status": "running" if speed > 0 else "idle"
                })
        
        print(f"💾 Inserting {len(data_points)} telemetry records...")
        
        # Batch insert for performance
        batch_size = 1000
        for i in range(0, len(data_points), batch_size):
            batch = data_points[i:i + batch_size]
            
            query = text("""
                INSERT INTO telemetry_records 
                (vehicle_id, ts, speed, lat, lon, fuel_level, 
                 coolant_temp, rpm, battery_voltage, odometer_km, idle_flag, engine_status)
                VALUES 
                (:vehicle_id, :ts, :speed, :lat, :lon, :fuel_level,
                 :coolant_temp, :rpm, :battery_voltage, :odometer_km, :idle_flag, :engine_status)
            """)
            
            for point in batch:
                await ts_session.execute(query, point)
            
            await ts_session.commit()
            print(f"  ✓ Inserted batch {i//batch_size + 1}/{(len(data_points) + batch_size - 1)//batch_size}")
        
        print(f"✅ Seeded {len(data_points)} telemetry records")


async def seed_aggregated_metrics():
    """Create aggregated metrics for faster dashboard queries"""
    async with TimescaleSessionLocal() as session:
        print("📈 Refreshing materialized views...")
        
        try:
            # Refresh the continuous aggregates
            await session.execute(text("CALL refresh_continuous_aggregate('telemetry_hourly', NULL, NULL)"))
            await session.execute(text("CALL refresh_continuous_aggregate('telemetry_daily', NULL, NULL)"))
            await session.commit()
            print("✅ Refreshed aggregated metrics")
        except Exception as e:
            print(f"⚠️  Could not refresh materialized views: {e}")


async def main():
    """Main seed function"""
    print("🌱 Starting telemetry data seeding...\n")
    
    try:
        await seed_telemetry_data()
        await seed_aggregated_metrics()
        
        print("\n✅ Telemetry seeding complete!")
        print("💡 Run the simulator for real-time data: python scripts/simulator.py")
        
    except Exception as e:
        print(f"\n❌ Error seeding telemetry: {e}")
        import traceback
        traceback.print_exc()
        raise


if __name__ == "__main__":
    asyncio.run(main())

