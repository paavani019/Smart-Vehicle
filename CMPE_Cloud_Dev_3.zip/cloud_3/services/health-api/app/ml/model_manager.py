"""ML Model Manager for predictive maintenance"""

import logging
import os
from pathlib import Path
import joblib
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import StandardScaler

from app.config import settings

logger = logging.getLogger(__name__)


class ModelManager:
    """Manages ML models for predictive maintenance"""
    
    def __init__(self):
        self.model = None
        self.scaler = None
        self.feature_names = [
            'avg_coolant_temp',
            'avg_battery_voltage',
            'avg_rpm',
            'max_speed',
            'idle_time_pct',
            'days_since_service',
            'odometer_km'
        ]
    
    async def load_models(self):
        """Load pre-trained models or train baseline"""
        model_path = Path(settings.MODEL_PATH) / "maintenance_model.joblib"
        scaler_path = Path(settings.MODEL_PATH) / "scaler.joblib"
        
        try:
            if model_path.exists() and scaler_path.exists():
                self.model = joblib.load(model_path)
                self.scaler = joblib.load(scaler_path)
                logger.info("✅ Loaded pre-trained models")
            else:
                # Train a simple baseline model
                logger.info("Training baseline model...")
                self._train_baseline_model()
                
                # Save models
                os.makedirs(settings.MODEL_PATH, exist_ok=True)
                joblib.dump(self.model, model_path)
                joblib.dump(self.scaler, scaler_path)
                logger.info("✅ Baseline model trained and saved")
        except Exception as e:
            logger.error(f"❌ Failed to load/train models: {e}")
            # Create a dummy model for development
            self._create_dummy_model()
    
    def _train_baseline_model(self):
        """Train a baseline RandomForest model with synthetic data"""
        # Generate synthetic training data
        np.random.seed(42)
        n_samples = 1000
        
        X = np.random.rand(n_samples, len(self.feature_names))
        
        # Synthetic labels based on simple rules
        # High coolant temp OR low battery OR high idle time = needs maintenance
        y = (
            (X[:, 0] > 0.7) |  # high coolant
            (X[:, 1] < 0.3) |  # low battery
            (X[:, 4] > 0.6) |  # high idle time
            (X[:, 5] > 0.8)    # long since service
        ).astype(int)
        
        # Scale features
        self.scaler = StandardScaler()
        X_scaled = self.scaler.fit_transform(X)
        
        # Train RandomForest
        self.model = RandomForestClassifier(
            n_estimators=100,
            max_depth=10,
            random_state=42
        )
        self.model.fit(X_scaled, y)
        
        logger.info(f"Baseline model trained with {n_samples} samples")
    
    def _create_dummy_model(self):
        """Create a dummy model for development"""
        self.model = None
        self.scaler = None
        logger.warning("⚠️ Using dummy model (predictions will be random)")
    
    def predict_maintenance(self, features: dict) -> tuple[str, float, str]:
        """
        Predict maintenance needs
        Returns: (predicted_issue, confidence, severity)
        """
        try:
            if self.model is None or self.scaler is None:
                # Return dummy prediction
                return self._dummy_prediction(features)
            
            # Extract features in correct order
            X = np.array([[
                features.get('avg_coolant_temp', 85.0),
                features.get('avg_battery_voltage', 12.5),
                features.get('avg_rpm', 2000),
                features.get('max_speed', 80),
                features.get('idle_time_pct', 0.1),
                features.get('days_since_service', 30),
                features.get('odometer_km', 15000)
            ]])
            
            # Scale features
            X_scaled = self.scaler.transform(X)
            
            # Predict
            prediction = self.model.predict(X_scaled)[0]
            confidence = self.model.predict_proba(X_scaled)[0][prediction]
            
            if prediction == 1:
                # Determine specific issue based on features
                issue, severity = self._determine_issue(features, confidence)
                return issue, float(confidence), severity
            else:
                return "No maintenance required", float(confidence), "Low"
        
        except Exception as e:
            logger.error(f"Prediction error: {e}")
            return self._dummy_prediction(features)
    
    def _determine_issue(self, features: dict, confidence: float) -> tuple[str, str]:
        """Determine specific maintenance issue and severity"""
        coolant = features.get('avg_coolant_temp', 85)
        battery = features.get('avg_battery_voltage', 12.5)
        idle_pct = features.get('idle_time_pct', 0.1)
        days_since = features.get('days_since_service', 30)
        
        # Priority-based issue detection
        if coolant > 95:
            return "Cooling System Check Required", "High" if confidence > 0.8 else "Medium"
        elif battery < 12.0:
            return "Battery Replacement Recommended", "High" if confidence > 0.8 else "Medium"
        elif idle_pct > 0.4:
            return "Engine Diagnostics Required", "Medium"
        elif days_since > 180:
            return "Scheduled Maintenance Overdue", "Medium"
        else:
            return "General Inspection Recommended", "Low"
    
    def _dummy_prediction(self, features: dict) -> tuple[str, float, str]:
        """Return dummy prediction for development"""
        # Simple rule-based prediction
        days_since = features.get('days_since_service', 30)
        odometer = features.get('odometer_km', 15000)
        coolant = features.get('avg_coolant_temp', 85)
        
        if days_since > 180 or odometer % 10000 < 500:
            return "Scheduled Maintenance Due", 0.85, "Medium"
        elif coolant > 95:
            return "Cooling System Check", 0.75, "High"
        elif days_since > 90:
            return "General Inspection Recommended", 0.65, "Low"
        else:
            return "No maintenance required", 0.90, "Low"
    
    def calculate_health_score(self, features: dict) -> float:
        """
        Calculate overall vehicle health score (0-100)
        Higher is better
        """
        score = 100.0
        
        # Penalize based on various factors
        coolant = features.get('avg_coolant_temp', 85)
        if coolant > 95:
            score -= 20
        elif coolant > 90:
            score -= 10
        
        battery = features.get('avg_battery_voltage', 12.5)
        if battery < 11.5:
            score -= 30
        elif battery < 12.0:
            score -= 15
        
        idle_pct = features.get('idle_time_pct', 0.1)
        score -= min(20, idle_pct * 50)
        
        days_since = features.get('days_since_service', 30)
        if days_since > 180:
            score -= 25
        elif days_since > 90:
            score -= 10
        
        return max(0, min(100, score))


# Global model manager instance
model_manager = ModelManager()

