"""
Analytics Worker - Scheduled Jobs
Performs windowed aggregations and generates daily reports
"""

import asyncio
import asyncpg
import logging
from datetime import datetime, timedelta
import os

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuration
DATABASE_URL = os.getenv('DATABASE_URL', 'postgresql://postgres:postgres@localhost:5432/fleet_db')
TIMESCALE_URL = os.getenv('TIMESCALE_URL', 'postgresql://postgres:postgres@localhost:5433/telemetry_db')


class AnalyticsWorker:
    def __init__(self):
        self.db_pool = None
        self.timescale_pool = None
    
    async def start(self):
        """Initialize connections"""
        logger.info("Starting Analytics Worker...")
        
        # Database pools
        self.db_pool = await asyncpg.create_pool(
            DATABASE_URL.replace('postgresql://', ''),
            min_size=2,
            max_size=10
        )
        
        self.timescale_pool = await asyncpg.create_pool(
            TIMESCALE_URL.replace('postgresql://', ''),
            min_size=2,
            max_size=10
        )
        
        logger.info("✅ Analytics Worker ready")
    
    async def stop(self):
        """Cleanup connections"""
        if self.db_pool:
            await self.db_pool.close()
        if self.timescale_pool:
            await self.timescale_pool.close()
    
    async def compute_vehicle_day_aggregates(self, target_date: datetime.date = None):
        """
        Compute daily aggregates for all vehicles
        drive_time, idle_time, avg_speed, utilization
        """
        if not target_date:
            target_date = (datetime.utcnow() - timedelta(days=1)).date()
        
        logger.info(f"Computing vehicle aggregates for {target_date}...")
        
        async with self.timescale_pool.acquire() as conn:
            query = """
                SELECT 
                    vehicle_id,
                    DATE(ts) as date,
                    COUNT(*) * 5.0 / 3600 as drive_time_hr,
                    SUM(CASE WHEN idle_flag THEN 1 ELSE 0 END) * 5.0 / 3600 as idle_time_hr,
                    AVG(speed) as avg_speed_kmph,
                    MAX(odometer_km) - MIN(odometer_km) as distance_km
                FROM telemetry_records
                WHERE DATE(ts) = $1
                GROUP BY vehicle_id, DATE(ts)
            """
            
            rows = await conn.fetch(query, target_date)
            
            logger.info(f"  Computed aggregates for {len(rows)} vehicles")
            
            # In production, would store these aggregates in a dedicated table
            # For now, they're available via TimescaleDB continuous aggregates
        
        return len(rows)
    
    async def generate_daily_report(self, target_date: datetime.date = None):
        """Generate daily fleet report"""
        if not target_date:
            target_date = (datetime.utcnow() - timedelta(days=1)).date()
        
        logger.info(f"Generating daily report for {target_date}...")
        
        # Compute aggregates
        vehicle_count = await self.compute_vehicle_day_aggregates(target_date)
        
        # Store report metadata
        async with self.db_pool.acquire() as conn:
            await conn.execute("""
                INSERT INTO reports (kind, period, status, created_at)
                VALUES ($1, $2, $3, $4)
                ON CONFLICT DO NOTHING
            """,
                'daily',
                {'date': str(target_date)},
                'completed',
                datetime.utcnow()
            )
        
        logger.info(f"  ✅ Daily report generated ({vehicle_count} vehicles)")
    
    async def update_vehicle_health_scores(self):
        """Update cached vehicle health scores"""
        logger.info("Updating vehicle health scores...")
        
        async with self.timescale_pool.acquire() as conn:
            # Get recent telemetry for each vehicle
            query = """
                SELECT 
                    vehicle_id,
                    AVG(coolant_temp) as avg_coolant,
                    AVG(battery_voltage) as avg_battery,
                    SUM(CASE WHEN idle_flag THEN 1 ELSE 0 END)::float / COUNT(*)::float as idle_pct
                FROM telemetry_records
                WHERE ts >= NOW() - INTERVAL '7 days'
                GROUP BY vehicle_id
            """
            
            rows = await conn.fetch(query)
        
        # Calculate scores and update database
        async with self.db_pool.acquire() as conn:
            for row in rows:
                score = 100.0
                
                # Penalize based on factors
                if row['avg_coolant'] and row['avg_coolant'] > 95:
                    score -= 20
                elif row['avg_coolant'] and row['avg_coolant'] > 90:
                    score -= 10
                
                if row['avg_battery'] and row['avg_battery'] < 12.0:
                    score -= 25
                
                if row['idle_pct']:
                    score -= min(20, row['idle_pct'] * 50)
                
                score = max(0, min(100, score))
                
                # Update or insert
                await conn.execute("""
                    INSERT INTO vehicle_health_scores (vehicle_id, health_score, updated_at)
                    VALUES ($1, $2, $3)
                    ON CONFLICT (vehicle_id) 
                    DO UPDATE SET health_score = $2, updated_at = $3
                """,
                    row['vehicle_id'],
                    score,
                    datetime.utcnow()
                )
        
        logger.info(f"  ✅ Updated health scores for {len(rows)} vehicles")
    
    async def run_scheduled_tasks(self):
        """Run scheduled analytics tasks"""
        while True:
            try:
                current_time = datetime.utcnow()
                
                # Run daily report at 1 AM UTC
                if current_time.hour == 1 and current_time.minute < 5:
                    await self.generate_daily_report()
                
                # Update health scores every hour
                if current_time.minute < 5:
                    await self.update_vehicle_health_scores()
                
                # Sleep for 5 minutes
                await asyncio.sleep(300)
            
            except Exception as e:
                logger.error(f"Error in scheduled tasks: {e}")
                await asyncio.sleep(60)
    
    async def run(self):
        """Main worker loop"""
        await self.start()
        
        try:
            logger.info("🔄 Analytics worker running...")
            await self.run_scheduled_tasks()
        
        except KeyboardInterrupt:
            logger.info("Shutting down...")
        
        finally:
            await self.stop()


async def main():
    worker = AnalyticsWorker()
    await worker.run()


if __name__ == "__main__":
    asyncio.run(main())

