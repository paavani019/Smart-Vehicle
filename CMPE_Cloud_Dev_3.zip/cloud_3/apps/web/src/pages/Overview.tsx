import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { api } from '@/lib/api'
import { TrendingUp, Clock, AlertTriangle, Truck } from 'lucide-react'

export function Overview() {
  const { data: kpis, isLoading } = useQuery({
    queryKey: ['kpis'],
    queryFn: () => api.getKPIs().then(res => res.data),
    refetchInterval: 30000, // Refresh every 30s
  })

  const { data: alerts } = useQuery({
    queryKey: ['alerts', 'active'],
    queryFn: () => api.getAlerts({ status: 'active' }).then(res => res.data),
    refetchInterval: 30000,
  })

  const { data: maintenanceAlerts } = useQuery({
    queryKey: ['maintenance-alerts'],
    queryFn: () => api.getMaintenanceAlerts().then(res => res.data),
  })

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="text-muted-foreground">Loading...</div>
      </div>
    )
  }

  const stats = [
    {
      name: 'Active Vehicles',
      value: kpis?.active_vehicles || 0,
      icon: Truck,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
    },
    {
      name: 'On-Time %',
      value: `${kpis?.on_time_percent?.toFixed(1) || 0}%`,
      icon: TrendingUp,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
    },
    {
      name: 'Fleet Idle %',
      value: `${kpis?.idle_percent?.toFixed(1) || 0}%`,
      icon: Clock,
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-50',
    },
    {
      name: 'Open Alerts',
      value: alerts?.total || 0,
      icon: AlertTriangle,
      color: 'text-red-600',
      bgColor: 'bg-red-50',
    },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Fleet Overview</h1>
        <p className="text-muted-foreground mt-1">
          Real-time fleet monitoring and analytics
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <Card key={stat.name}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.name}</p>
                  <p className="text-3xl font-bold mt-2">{stat.value}</p>
                </div>
                <div className={`${stat.bgColor} p-3 rounded-lg`}>
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Alerts */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Alerts</CardTitle>
          </CardHeader>
          <CardContent>
            {alerts && alerts.alerts?.length > 0 ? (
              <div className="space-y-3">
                {alerts.alerts.slice(0, 5).map((alert: any) => (
                  <div
                    key={alert.event_id}
                    className="flex items-start justify-between p-3 bg-gray-50 rounded-lg"
                  >
                    <div className="flex-1">
                      <p className="font-medium text-sm">{alert.summary}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {alert.vehicle_id} • {new Date(alert.created_at).toLocaleTimeString()}
                      </p>
                    </div>
                    <span
                      className={`px-2 py-1 text-xs font-medium rounded ${
                        alert.severity === 'HIGH'
                          ? 'bg-red-100 text-red-700'
                          : alert.severity === 'MEDIUM'
                          ? 'bg-yellow-100 text-yellow-700'
                          : 'bg-blue-100 text-blue-700'
                      }`}
                    >
                      {alert.severity}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No active alerts</p>
            )}
          </CardContent>
        </Card>

        {/* Maintenance Due */}
        <Card>
          <CardHeader>
            <CardTitle>Maintenance Due</CardTitle>
          </CardHeader>
          <CardContent>
            {maintenanceAlerts && maintenanceAlerts.length > 0 ? (
              <div className="space-y-3">
                {maintenanceAlerts.slice(0, 5).map((alert: any) => (
                  <div
                    key={alert.id}
                    className="flex items-start justify-between p-3 bg-gray-50 rounded-lg"
                  >
                    <div className="flex-1">
                      <p className="font-medium text-sm">{alert.predicted_issue}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {alert.vehicle_id} • Due: {alert.due_date || 'TBD'}
                      </p>
                    </div>
                    <span className="text-xs font-medium text-yellow-700">
                      {(alert.confidence * 100).toFixed(0)}%
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-sm text-muted-foreground">No maintenance due</p>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Map Placeholder */}
      <Card>
        <CardHeader>
          <CardTitle>Live Fleet Map</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-96 bg-gray-100 rounded-lg flex items-center justify-center">
            <p className="text-muted-foreground">
              Map integration (Leaflet) - Install leaflet and react-leaflet to enable
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

