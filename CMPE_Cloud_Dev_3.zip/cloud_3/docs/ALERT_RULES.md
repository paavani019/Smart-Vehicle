# Alert Rules - Decision Tables

This document describes the comprehensive alert rule engine implementation.

## Rule Evaluation Order

1. **Safety** (Critical priority)
2. **Compliance/SLA**
3. **Operational**
4. **Informational**

## Rule 1: Speeding (Context-Aware)

### Inputs
- `speed_kmph`: Current vehicle speed
- `road_limit_kmph`: Posted speed limit
- `consecutive_violations`: Number of consecutive speeding events
- `road_type`: urban | highway | school_zone | residential

### Decision Table

| Δ (km/h) | Road Type | Violations | Severity | Actions |
|----------|-----------|------------|----------|---------|
| ≥30 | any | ≥3 | HIGH | notify_ops + sms_driver |
| ≥20 | highway | ≥2 | MEDIUM | email_driver |
| ≥15 | urban | ≥2 | MEDIUM | email_driver |
| ≥10 | school_zone | ≥1 | HIGH | escalate + sms_driver |
| 5-14 | any | ≥3 | LOW | score_impact |
| <5 | any | any | NONE | - |

### Reset Condition
Clear `consecutive_violations` after 30 minutes of compliant driving.

---

## Rule 2: Excess Idle

### Inputs
- `engine_status`: ON | OFF | IDLE
- `speed`: Current speed (km/h)
- `idle_minutes`: Duration of idle time
- `ambient_temp`: Ambient temperature (°C)

### Decision Table

| Engine | Speed | Idle (min) | Ambient | Severity | Actions |
|--------|-------|------------|---------|----------|---------|
| ON/IDLE | 0 | ≥30 | any | HIGH | notify_dispatcher |
| ON/IDLE | 0 | ≥20 | any | MEDIUM | app_ping |
| ON/IDLE | 0 | ≥10 | <0 or >35 | LOW | advisory |
| ON/IDLE | 0 | <10 | any | NONE | - |

---

## Rule 3: Route Deviation / Geofence

### Inputs
- `deviation_meters`: Distance from planned route
- `is_planned_route`: Boolean
- `delay_minutes`: Delay from schedule

### Decision Table

| Deviation (m) | Planned | Delay (min) | Severity | Actions |
|---------------|---------|-------------|----------|---------|
| ≥1000 | No | ≥10 | HIGH | notify_ops + driver_confirmation |
| 200-999 | No | ≥5 | MEDIUM | app_ping |
| ≤200 | No | any | LOW | log |
| any | Yes | any | NONE | - |

---

## Rule 4: Maintenance Scheduling

### Inputs
- `km_since_last_service`: Odometer delta
- `days_since_service`: Days since last service
- `has_critical_dtc`: Critical diagnostic trouble code present
- `predictive_health_score`: ML model score (0-1)

### Decision Table

| KM Since | Days Since | Critical DTC | Health Score | Severity | Actions |
|----------|------------|--------------|--------------|----------|---------|
| ≥10,000 | any | Yes | any | HIGH | pull_from_service + ticket |
| 7,500-9,999 | any | any | ≥0.7 | MEDIUM | schedule_within_7_days |
| any | ≥180 | any | ≥0.5 | MEDIUM | schedule_within_14_days |
| <7,500 | <180 | No | <0.5 | NONE | - |

---

## Rule 5: Connectivity / Offline

### Inputs
- `minutes_since_last_telemetry`: Time since last data
- `gps_fix`: ok | lost
- `ignition`: ON | OFF

### Decision Table

| Minutes | GPS Fix | Ignition | Severity | Actions |
|---------|---------|----------|----------|---------|
| ≥30 | lost | ON | HIGH | call_driver + ticket |
| 10-29 | lost | any | MEDIUM | monitor |
| ≥60 | any | OFF | LOW | log (parked) |
| <10 | any | any | NONE | - |

---

## Rule 6: SLA / ETA Breach

### Inputs
- `eta_delta_minutes`: Difference from scheduled ETA
- `priority`: A | B | C
- `window_end_minutes`: Time until delivery window closes

### Decision Table

| ETA Δ (min) | Priority | Window End (min) | Severity | Actions |
|-------------|----------|------------------|----------|---------|
| ≥20 | A | ≤30 | HIGH | notify_customer + reroute + escalate |
| 10-19 | A or B | ≤60 | MEDIUM | notify_customer |
| 5-9 | any | any | LOW | log |
| <5 | any | any | NONE | - |

---

## Suppression & Deduplication

### Suppression Rules
1. Suppress **Speeding** and **Idle** alerts when vehicle status = `maintenance`
2. Suppress **Route Deviation** when vehicle is in depot
3. Suppress **Offline** alerts during scheduled maintenance windows

### Deduplication
- Suppress identical alerts within **10 minutes** for same vehicle + rule
- Use Redis cache with TTL for deduplication tracking

---

## Escalation Policy

### Unacknowledged HIGH Alerts
- **15 minutes**: Escalate to manager
- **30 minutes**: Escalate to on-call

### Unacknowledged CRITICAL Alerts
- **5 minutes**: Escalate to manager
- **10 minutes**: Escalate to on-call + SMS

---

## Notification Channels

| Channel | Use Case | Dev Implementation |
|---------|----------|-------------------|
| **Email** | Non-urgent alerts | Logged (SendGrid in prod) |
| **SMS** | Urgent alerts | Logged (Twilio in prod) |
| **App Push** | Driver notifications | WebSocket |
| **Webhook** | External integrations | HTTP POST |

---

## Testing Alert Rules

### Manual Trigger
```bash
curl -X POST http://localhost:8004/v1/alerts/evaluate \
  -H "Content-Type: application/json" \
  -d '{
    "vehicle_id": "VEH-001",
    "speed": 120,
    "road_limit_kmph": 80,
    "road_type": "urban",
    "consecutive_violations": 3
  }'
```

### Expected Response
```json
{
  "evaluated": 6,
  "suppressed": 0,
  "deduplicated": 0,
  "created": 1,
  "alerts": [
    {
      "event_id": "...",
      "vehicle_id": "VEH-001",
      "severity": "HIGH",
      "summary": "Severe speeding: 40km/h over limit (3 violations)"
    }
  ]
}
```

