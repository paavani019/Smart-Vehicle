"""SQLAlchemy models"""

from sqlalchemy import Column, String, Integer, DateTime, JSON, Enum, DECIMAL, Boolean, ForeignKey, BigInteger, Text
from sqlalchemy.dialects.postgresql import UUID
from datetime import datetime
import uuid
import enum

from app.database import Base


class UserRole(str, enum.Enum):
    admin = "admin"
    operator = "operator"
    driver = "driver"


class VehicleStatus(str, enum.Enum):
    active = "active"
    maintenance = "maintenance"
    offline = "offline"


class User(Base):
    __tablename__ = "users"
    
    user_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String(255), unique=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(Enum(UserRole, name="user_role"), nullable=False, default=UserRole.driver)
    name = Column(String(255))
    phone = Column(String(50))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    last_login = Column(DateTime)


class Vehicle(Base):
    __tablename__ = "vehicles"
    
    vehicle_id = Column(String(50), primary_key=True)
    plate_number = Column(String(50), unique=True, nullable=False)
    make = Column(String(100))
    model = Column(String(100))
    year = Column(Integer)
    status = Column(Enum(VehicleStatus, name="vehicle_status"), nullable=False, default=VehicleStatus.active)
    last_service_date = Column(DateTime)
    next_service_due = Column(DateTime)
    odometer_km = Column(DECIMAL(10, 2), default=0)
    assigned_driver_id = Column(UUID(as_uuid=True), ForeignKey("drivers.driver_id"))
    region = Column(String(100))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class Driver(Base):
    __tablename__ = "drivers"
    
    driver_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.user_id"))
    name = Column(String(255), nullable=False)
    phone = Column(String(50))
    license_number = Column(String(100))
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class IngestionJob(Base):
    __tablename__ = "ingestion_jobs"
    
    job_id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    vehicle_id = Column(String(50), ForeignKey("vehicles.vehicle_id"))
    status = Column(String(50), nullable=False, default="QUEUED")
    job_type = Column(String(50), nullable=False)
    file_size_bytes = Column(BigInteger)
    file_path = Column(Text)
    validation_errors = Column(JSON)
    kafka_offset = Column(BigInteger)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

