/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_API_BASE_URL: string
  readonly VITE_INGESTION_API: string
  readonly VITE_HEALTH_API: string
  readonly VITE_ANALYTICS_API: string
  readonly VITE_ALERTS_API: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}

