# Fleet Monitoring Dashboard

Real-Time Fleet Monitoring Dashboard for Smart Car Cloud Platform.

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ and npm

### Setup Steps

1. **Install dependencies:**
```bash
npm install
```

2. **Optional: Configure Mapbox (for map visualization)**
   - Copy `.env.example` to `.env`
   - Add your Mapbox access token (get one from https://account.mapbox.com/access-tokens/)
   - If you don't have a token, the map will show a placeholder message

3. **Start the mock backend server:**
```bash
npm run backend
```
   The backend will run on `http://localhost:3001`

4. **Start the React frontend (in a new terminal):**
```bash
npm run dev
```

5. **Access the dashboard:**
   Open http://localhost:5173 in your browser

## 📋 Features

### Overview Page
- **KPI Cards**: On-Time %, Idle Hours, Active Vehicles, Open Alerts
- **Vehicle Status Table**: Real-time status of all vehicles with speed, fuel, and on-time indicators
- Auto-refreshes every 30 seconds

### Map View
- **Real-time Vehicle Tracking**: Live positions of all vehicles on an interactive map
- **Status Indicators**: Color-coded markers (green=active, yellow=idle, red=maintenance)
- **Vehicle Popups**: Click markers to see vehicle details
- Auto-updates every 10 seconds

### Alerts Center
- **Active Alerts List**: All current alerts with severity levels
- **Severity Color Coding**: High (red), Medium (yellow), Low (blue)
- **Alert Types**: Speeding, Idle, Maintenance, Fuel warnings
- **Quick Navigation**: Direct links to vehicle details
- Auto-refreshes every 15 seconds

### Vehicle Detail View
- **Telemetry Charts**: Speed and Fuel level over time (last 24 hours)
- **Maintenance Information**: Health score, service schedule, component status
- **Location Data**: Current coordinates with link to map view
- Auto-refreshes every 30 seconds

### Reports Page
- **Daily Summary**: Total vehicles, distance, fuel consumption, alerts
- **Vehicle Performance Table**: Individual vehicle metrics
- **Export Functionality**: Download reports as text files

## 🔌 API Endpoints

The mock backend provides the following endpoints:

- `GET /analytics/kpi` - Overall fleet performance metrics
- `GET /telemetry/latest` - Latest GPS, speed, and fuel data for all vehicles
- `GET /alerts` - Active alert list with severity
- `GET /vehicles/:id` - Vehicle-level details with telemetry history
- `GET /reports/daily` - Aggregated daily analytics summary

## 🛠️ Tech Stack

- **Frontend:**
  - React 18 + Vite
  - React Router for navigation
  - Tailwind CSS for styling
  - Recharts for data visualization
  - Mapbox GL JS for maps
  - Axios for API calls

- **Backend:**
  - Node.js + Express
  - CORS enabled for development
  - Mock data with realistic vehicle scenarios

## 📁 Project Structure

```
fleet-monitoring-dashboard/
├── backend/
│   └── server.js          # Mock API server
├── src/
│   ├── api/
│   │   └── api.js         # API service layer
│   ├── components/
│   │   └── Layout.jsx     # Main layout with navigation
│   ├── pages/
│   │   ├── Overview.jsx   # Dashboard overview
│   │   ├── MapView.jsx    # Real-time map
│   │   ├── Alerts.jsx     # Alerts center
│   │   ├── VehicleDetail.jsx  # Vehicle details
│   │   └── Reports.jsx    # Reports page
│   ├── App.jsx            # Main app component
│   ├── main.jsx           # Entry point
│   └── index.css          # Global styles
├── package.json
├── vite.config.js
├── tailwind.config.js
└── README.md
```

## 🔄 Data Flow

1. Mock backend generates vehicle telemetry and alerts
2. Frontend fetches data via REST API calls
3. Components render data with real-time updates
4. Charts and maps visualize the data
5. Users can navigate between views and export reports

## 🚢 Deployment

For production deployment to AWS EC2:

1. Build the frontend: `npm run build`
2. Set up Nginx to serve the static files
3. Run the backend as a service (PM2 recommended)
4. Update `VITE_API_URL` in production environment
5. Configure Mapbox token for map visualization

## 📝 Notes

- The backend uses mock data for demonstration
- Replace API endpoints in `src/api/api.js` to connect to real backend
- Mapbox token is optional but recommended for full map functionality
- All data refreshes automatically at configured intervals

