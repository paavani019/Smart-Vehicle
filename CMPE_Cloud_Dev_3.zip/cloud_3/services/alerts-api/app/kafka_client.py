"""Kafka client for publishing alert events"""

from aiokafka import AIOKafkaProducer
from app.config import settings
import json
import logging

logger = logging.getLogger(__name__)


class KafkaClient:
    def __init__(self):
        self.producer: AIOKafkaProducer | None = None
        
    async def start(self):
        """Start Kafka producer"""
        try:
            self.producer = AIOKafkaProducer(
                bootstrap_servers=settings.KAFKA_BOOTSTRAP_SERVERS,
                value_serializer=lambda v: json.dumps(v).encode('utf-8')
            )
            await self.producer.start()
            logger.info(f"✅ Kafka producer connected")
        except Exception as e:
            logger.error(f"❌ Failed to start Kafka producer: {e}")
            self.producer = None
    
    async def stop(self):
        """Stop Kafka producer"""
        if self.producer:
            await self.producer.stop()
    
    async def publish(self, topic: str, message: dict, key: str | None = None):
        """Publish message to Kafka topic"""
        if not self.producer:
            logger.warning("Kafka producer not available")
            return None
        
        try:
            key_bytes = key.encode('utf-8') if key else None
            metadata = await self.producer.send_and_wait(topic, value=message, key=key_bytes)
            return metadata.offset
        except Exception as e:
            logger.error(f"Failed to publish to Kafka: {e}")
            raise


kafka_client = KafkaClient()

