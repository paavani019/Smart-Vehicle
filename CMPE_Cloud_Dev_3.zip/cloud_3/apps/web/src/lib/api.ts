import axios from 'axios'

const INGESTION_API = import.meta.env.VITE_INGESTION_API || 'http://localhost:8001'
const HEALTH_API = import.meta.env.VITE_HEALTH_API || 'http://localhost:8002'
const ANALYTICS_API = import.meta.env.VITE_ANALYTICS_API || 'http://localhost:8003'
const ALERTS_API = import.meta.env.VITE_ALERTS_API || 'http://localhost:8004'

export const ingestionApi = axios.create({
  baseURL: `${INGESTION_API}/v1`,
  headers: {
    'Content-Type': 'application/json',
  },
})

export const healthApi = axios.create({
  baseURL: `${HEALTH_API}/v1`,
  headers: {
    'Content-Type': 'application/json',
  },
})

export const analyticsApi = axios.create({
  baseURL: `${ANALYTICS_API}/v1`,
  headers: {
    'Content-Type': 'application/json',
  },
})

export const alertsApi = axios.create({
  baseURL: `${ALERTS_API}/v1`,
  headers: {
    'Content-Type': 'application/json',
  },
})

// Add auth token to all requests
const apis = [ingestionApi, healthApi, analyticsApi, alertsApi]
apis.forEach(api => {
  api.interceptors.request.use(config => {
    const token = localStorage.getItem('auth_token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  })
})

// API Functions
export const api = {
  // Auth
  login: (email: string, password: string) =>
    ingestionApi.post('/auth/login', { email, password }),

  // Telemetry
  getLatestTelemetry: () =>
    ingestionApi.get('/telemetry/latest'),
  
  getVehicleTelemetry: (vehicleId: string) =>
    ingestionApi.get(`/telemetry/latest/${vehicleId}`),

  // Health
  getMaintenancePrediction: (vehicleId: string) =>
    healthApi.get(`/maintenance/predict/${vehicleId}`),
  
  getHealthScore: (vehicleId: string) =>
    healthApi.get(`/health/score/${vehicleId}`),
  
  getMaintenanceAlerts: () =>
    healthApi.get('/maintenance/alerts'),

  // Analytics
  getKPIs: () =>
    analyticsApi.get('/analytics/kpi'),
  
  getTimeSummary: (params: { start_date: string; end_date: string; vehicle_id?: string }) =>
    analyticsApi.get('/analytics/time-summary', { params }),
  
  getDailyReport: (date: string, vehicleId?: string) =>
    analyticsApi.get('/analytics/daily-report', { params: { date, vehicle_id: vehicleId } }),

  // Alerts
  getAlerts: (params?: { severity?: string; vehicle_id?: string; status?: string }) =>
    alertsApi.get('/alerts', { params }),
  
  acknowledgeAlert: (alertId: string, userId: string) =>
    alertsApi.put(`/alerts/${alertId}/acknowledge`, { user_id: userId }),
  
  resolveAlert: (alertId: string, userId: string) =>
    alertsApi.put(`/alerts/${alertId}/resolve`, { user_id: userId }),

  // Reports
  generateReport: (kind: string, dateRange: { start: string; end: string }) =>
    analyticsApi.post('/reports/generate', {
      kind,
      date_range: dateRange,
    }),
  
  getReports: () =>
    analyticsApi.get('/reports'),
}

