"""Pydantic schemas for request/response validation"""

from pydantic import BaseModel, Field, validator
from typing import Optional, List, Dict, Any
from datetime import datetime
from uuid import UUID


class TelemetryRecord(BaseModel):
    """Single telemetry record"""
    vehicleId: str
    ts: str  # ISO8601 timestamp
    gps: Optional[List[float]] = None  # [lat, lon]
    speed: Optional[float] = None
    rpm: Optional[int] = None
    gear: Optional[int] = None
    coolantTemp: Optional[float] = None
    batteryVoltage: Optional[float] = None
    odometerKm: Optional[float] = None
    fuelLevel: Optional[float] = None
    engineStatus: Optional[str] = None
    
    @validator('gps')
    def validate_gps(cls, v):
        if v and len(v) != 2:
            raise ValueError('GPS must be [lat, lon]')
        if v and (abs(v[0]) > 90 or abs(v[1]) > 180):
            raise ValueError('Invalid GPS coordinates')
        return v


class TelemetryBatchRequest(BaseModel):
    """Batch telemetry upload"""
    records: List[TelemetryRecord]
    
    @validator('records')
    def validate_records(cls, v):
        if len(v) == 0:
            raise ValueError('Records cannot be empty')
        if len(v) > 1000:
            raise ValueError('Batch size cannot exceed 1000 records')
        return v


class TelemetryBatchResponse(BaseModel):
    """Response for batch upload"""
    status: str
    accepted: int
    rejected: int
    kafka_offsets: Optional[List[int]] = None
    errors: Optional[List[Dict[str, Any]]] = None


class DataUploadResponse(BaseModel):
    """Response for file upload"""
    jobId: str
    status: str
    vehicleId: str
    message: str


class IngestionJobStatus(BaseModel):
    """Ingestion job status"""
    jobId: str
    status: str
    vehicleId: str
    jobType: str
    errors: Optional[List[str]] = None
    createdAt: datetime
    updatedAt: datetime


class VehicleStatusResponse(BaseModel):
    """Vehicle ingestion status"""
    vehicleId: str
    pendingJobs: int
    recent: List[IngestionJobStatus]


class LatestTelemetry(BaseModel):
    """Latest telemetry snapshot"""
    vehicleId: str
    timestamp: datetime
    location: Optional[Dict[str, float]] = None
    speed: Optional[float] = None
    status: str


class LoginRequest(BaseModel):
    """Login request"""
    email: str
    password: str


class LoginResponse(BaseModel):
    """Login response"""
    access_token: str
    token_type: str = "bearer"
    expires_in: int
    role: str
    user_id: str

