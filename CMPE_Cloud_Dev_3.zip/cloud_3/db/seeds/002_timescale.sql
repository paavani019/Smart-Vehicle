-- TimescaleDB Time-Series Schema
-- PostgreSQL 15+ with TimescaleDB extension

-- Enable TimescaleDB extension
CREATE EXTENSION IF NOT EXISTS timescaledb;

-- Telemetry records table (hypertable for time-series data)
CREATE TABLE IF NOT EXISTS telemetry_records (
    vehicle_id VARCHAR(50) NOT NULL,
    ts TIMESTAMPTZ NOT NULL,
    lat DECIMAL(10, 7),
    lon DECIMAL(10, 7),
    speed DECIMAL(6, 2),
    rpm INTEGER,
    fuel_level DECIMAL(5, 2),
    engine_status VARCHAR(50),
    idle_flag BOOLEAN DEFAULT FALSE,
    coolant_temp DECIMAL(5, 2),
    battery_voltage DECIMAL(5, 2),
    tire_pressure JSONB,
    odometer_km DECIMAL(10, 2),
    gear INTEGER,
    route_context JSONB,
    flags JSONB,
    PRIMARY KEY (vehicle_id, ts)
);

-- Convert to hypertable (partition by time)
SELECT create_hypertable('telemetry_records', 'ts', 
    chunk_time_interval => INTERVAL '1 day',
    if_not_exists => TRUE
);

-- Create indexes for common queries
CREATE INDEX IF NOT EXISTS idx_telemetry_vehicle_ts ON telemetry_records (vehicle_id, ts DESC);
CREATE INDEX IF NOT EXISTS idx_telemetry_ts ON telemetry_records (ts DESC);
CREATE INDEX IF NOT EXISTS idx_telemetry_idle ON telemetry_records (vehicle_id, ts DESC) WHERE idle_flag = TRUE;

-- Continuous aggregate for hourly vehicle stats
CREATE MATERIALIZED VIEW IF NOT EXISTS telemetry_hourly
WITH (timescaledb.continuous) AS
SELECT
    vehicle_id,
    time_bucket('1 hour', ts) AS bucket,
    AVG(speed) AS avg_speed,
    MAX(speed) AS max_speed,
    AVG(rpm) AS avg_rpm,
    AVG(fuel_level) AS avg_fuel_level,
    AVG(coolant_temp) AS avg_coolant_temp,
    AVG(battery_voltage) AS avg_battery_voltage,
    COUNT(*) AS record_count,
    SUM(CASE WHEN idle_flag THEN 1 ELSE 0 END) AS idle_count
FROM telemetry_records
GROUP BY vehicle_id, bucket;

-- Refresh policy for continuous aggregate (refresh every hour)
SELECT add_continuous_aggregate_policy('telemetry_hourly',
    start_offset => INTERVAL '3 hours',
    end_offset => INTERVAL '1 hour',
    schedule_interval => INTERVAL '1 hour',
    if_not_exists => TRUE
);

-- Daily vehicle summary aggregate
CREATE MATERIALIZED VIEW IF NOT EXISTS telemetry_daily
WITH (timescaledb.continuous) AS
SELECT
    vehicle_id,
    time_bucket('1 day', ts) AS bucket,
    AVG(speed) AS avg_speed,
    MAX(speed) AS max_speed,
    MIN(speed) AS min_speed,
    AVG(rpm) AS avg_rpm,
    AVG(fuel_level) AS avg_fuel_level,
    AVG(coolant_temp) AS avg_coolant_temp,
    AVG(battery_voltage) AS avg_battery_voltage,
    COUNT(*) AS record_count,
    SUM(CASE WHEN idle_flag THEN 1 ELSE 0 END) AS idle_count,
    MAX(odometer_km) - MIN(odometer_km) AS distance_km
FROM telemetry_records
GROUP BY vehicle_id, bucket;

-- Refresh policy for daily aggregate
SELECT add_continuous_aggregate_policy('telemetry_daily',
    start_offset => INTERVAL '3 days',
    end_offset => INTERVAL '1 day',
    schedule_interval => INTERVAL '1 day',
    if_not_exists => TRUE
);

-- Retention policy: keep raw data for 90 days
SELECT add_retention_policy('telemetry_records', 
    INTERVAL '90 days',
    if_not_exists => TRUE
);

-- Compression policy: compress chunks older than 7 days
ALTER TABLE telemetry_records SET (
    timescaledb.compress,
    timescaledb.compress_segmentby = 'vehicle_id'
);

SELECT add_compression_policy('telemetry_records', 
    INTERVAL '7 days',
    if_not_exists => TRUE
);

