# Smart Vehicle Cloud Platform

A production-grade monorepo for Smart Vehicle Data Ingestion, Predictive Maintenance, and Real-Time Fleet Monitoring.

## 🏗️ Architecture Overview

```
┌─────────────────┐     ┌──────────────────┐     ┌─────────────────┐
│  React Frontend │────▶│  API Gateway     │────▶│  FastAPI Services│
│  (Vite + TS)    │     │  (nginx)         │     │  - Ingestion    │
└─────────────────┘     └──────────────────┘     │  - Health/ML    │
                                                  │  - Analytics    │
                                                  │  - Alerts       │
                                                  └─────────────────┘
                                                          │
                        ┌─────────────────────────────────┼───────────────┐
                        │                                 │               │
                  ┌─────▼──────┐                 ┌────────▼────────┐     │
                  │  Kafka     │                 │  PostgreSQL +   │     │
                  │  (Redpanda)│                 │  TimescaleDB    │     │
                  └─────┬──────┘                 └─────────────────┘     │
                        │                                                 │
                  ┌─────▼──────┐                 ┌────────────────┐      │
                  │  Workers   │                 │  Redis Cache   │◀─────┘
                  │  - Process │                 └────────────────┘
                  │  - Analytics│                ┌────────────────┐
                  └────────────┘                 │  MinIO (S3)    │
                                                 └────────────────┘
```

## 🚀 Quick Start

### Prerequisites
- Docker & Docker Compose
- pnpm (for frontend)
- Python 3.11+
- Make

### Start Everything

```bash
# Start all services (Postgres, Kafka, Redis, MinIO, APIs, Frontend)
make up

# Seed database with sample data
make seed

# Start telemetry simulator (generates live vehicle data)
make simulate

# Open the dashboard
open http://localhost:5173
```

Default credentials:
- **Admin**: `admin@fleet.com` / `admin123`
- **Operator**: `operator@fleet.com` / `operator123`

### Stop Everything

```bash
make down
```

## 📦 Services Map

| Service | Port | Description |
|---------|------|-------------|
| **Frontend (React)** | 5173 | Fleet monitoring dashboard |
| **Ingestion API** | 8001 | Vehicle telemetry ingestion & validation |
| **Health API** | 8002 | Predictive maintenance & health scoring |
| **Analytics API** | 8003 | Time analytics & reports generation |
| **Alerts API** | 8004 | Rule engine & notification center |
| **PostgreSQL** | 5432 | Relational data (vehicles, alerts, users) |
| **TimescaleDB** | 5433 | Time-series telemetry data |
| **Kafka UI** | 8080 | Redpanda console |
| **MinIO Console** | 9001 | Object storage console (minioadmin/minioadmin) |
| **Grafana** | 3000 | Observability dashboards (admin/admin) |
| **Prometheus** | 9090 | Metrics collection |

## 🧪 Testing

```bash
# Run all tests
make test

# Run specific service tests
make test-ingestion
make test-health
make test-frontend

# Check test coverage
make coverage
```

## 📊 Key Features

### 1. Smart Vehicle Data Ingestion
- Multi-sensor data upload (GPS, CAN bus, IMU, camera metadata)
- Real-time validation & schema checking
- Kafka-based event streaming
- MinIO object storage for raw/curated data
- Rate limiting & backpressure handling

### 2. Predictive Maintenance & Health Scoring
- ML-based failure prediction (RandomForest baseline)
- Component-level health scoring (0-100)
- Maintenance scheduling & work order management
- Integration with alert engine for proactive notifications

### 3. Real-Time Fleet Monitoring
- Live vehicle tracking on interactive map (Leaflet)
- KPI dashboard (On-time %, Utilization, Idle time)
- Context-aware alerting (speeding, idle, route deviation, connectivity)
- Historical analytics & report generation (PDF/CSV)

## 🎯 Alert Rules

The platform implements a comprehensive rule engine with 6 core alert types:

1. **Speeding (Context-Aware)**: Urban vs highway vs school zone thresholds
2. **Excess Idle**: Time-based with ambient temperature context
3. **Route Deviation**: Geofence + planned route validation
4. **Maintenance Scheduling**: Odometer + predictive health triggers
5. **Connectivity/Offline**: GPS loss + ignition state matrix
6. **SLA/ETA Breach**: Priority-based delivery window tracking

See `/docs/ALERT_RULES.md` for complete decision tables.

## 🗂️ Repository Structure

```
/
├── README.md                    # This file
├── docker-compose.yml           # Full stack orchestration
├── Makefile                     # Common operations
├── pnpm-workspace.yaml          # Frontend monorepo config
├── .github/workflows/           # CI/CD pipelines
├── /apps
│   └── /web                     # React frontend (Vite + TypeScript)
├── /services
│   ├── /ingestion-api           # FastAPI - data ingestion
│   ├── /health-api              # FastAPI - ML predictions
│   ├── /analytics-api           # FastAPI - analytics & reports
│   ├── /alerts-api              # FastAPI - rule engine
│   └── /workers
│       ├── /preprocess-worker   # Kafka consumer - validation
│       └── /analytics-worker    # Kafka consumer - aggregations
├── /db
│   ├── /migrations              # Alembic migrations
│   └── /seeds                   # Sample data & simulator
├── /infra
│   ├── /grafana                 # Dashboards & datasources
│   └── /prometheus              # Metrics scraping config
├── /schemas                     # JSON schemas & OpenAPI fragments
└── /docs                        # Architecture & API docs
```

## 🛠️ Development

### Install Dependencies

```bash
# Frontend
cd apps/web && pnpm install

# Backend (each service)
cd services/ingestion-api && pip install -e .
# ... repeat for other services
```

### Run Services Individually

```bash
# Ingestion API
cd services/ingestion-api
uvicorn app.main:app --reload --port 8001

# Frontend
cd apps/web
pnpm dev
```

### Database Migrations

```bash
# Generate new migration
cd db/migrations
alembic revision --autogenerate -m "description"

# Apply migrations
alembic upgrade head
```

## 📈 Observability

- **Prometheus**: `http://localhost:9090`
  - Metrics: request latency, Kafka lag, validation errors
- **Grafana**: `http://localhost:3000`
  - Pre-configured dashboards for each service
- **OpenTelemetry**: Traces exported to console (configure OTLP endpoint in production)

## 🔐 Security

### Development Mode
- JWT with HS256 (secret in `.env`)
- RBAC: `admin`, `operator`, `driver`
- Rate limiting per user/vehicle
- mTLS disabled by default

### Production Checklist
- [ ] Enable mTLS between services
- [ ] Use RS256 JWT with key rotation
- [ ] Configure external secrets manager
- [ ] Enable audit logging to separate store
- [ ] Set up WAF rules
- [ ] Configure network policies

## 🚢 Deployment

### Docker Compose (Dev/Staging)
```bash
make up
```

### Kubernetes (Production)
See `/docs/KUBERNETES.md` for Helm charts and manifests.

## 🤝 Contributing

1. Create feature branch: `git checkout -b feature/my-feature`
2. Run tests: `make test`
3. Run linters: `make lint`
4. Submit PR

## 📝 License

MIT

## 🆘 Troubleshooting

### Kafka not connecting
```bash
docker-compose logs kafka
# Wait for "Redpanda started" message
```

### Database migrations failing
```bash
make db-reset
make seed
```

### Frontend not updating
```bash
cd apps/web
pnpm install
rm -rf node_modules/.vite
pnpm dev
```

## 📞 Support

- Documentation: `/docs`
- API Reference: `http://localhost:8001/docs` (each service)
- Issues: GitHub Issues

