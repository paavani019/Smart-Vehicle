"""Configuration settings for Alerts API"""

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings"""
    
    DATABASE_URL: str = "postgresql://postgres:postgres@localhost:5432/fleet_db"
    TIMESCALE_URL: str = "postgresql://postgres:postgres@localhost:5433/telemetry_db"
    
    KAFKA_BOOTSTRAP_SERVERS: str = "localhost:9092"
    KAFKA_TOPIC_ALERTS: str = "alerts.events"
    
    REDIS_URL: str = "redis://localhost:6379"
    
    JWT_SECRET: str = "dev-secret-change-in-production"
    JWT_ALGORITHM: str = "HS256"
    
    # Alert thresholds
    ALERT_DEDUP_WINDOW_MINUTES: int = 10
    ALERT_ESCALATION_MINUTES: int = 15
    ALERT_SUPPRESSION_ENABLED: bool = True
    
    class Config:
        env_file = ".env"


settings = Settings()

