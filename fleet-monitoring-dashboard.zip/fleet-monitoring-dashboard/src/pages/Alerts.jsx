import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { fetchAlerts } from '../api/api';

const Alerts = () => {
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadAlerts = async () => {
      try {
        const data = await fetchAlerts();
        setAlerts(data);
      } catch (error) {
        console.error('Error loading alerts:', error);
      } finally {
        setLoading(false);
      }
    };

    loadAlerts();
    const interval = setInterval(loadAlerts, 15000); // Refresh every 15 seconds

    return () => clearInterval(interval);
  }, []);

  const getSeverityColor = (severity) => {
    switch (severity) {
      case 'high':
        return 'bg-red-100 text-red-800 border-red-300';
      case 'medium':
        return 'bg-yellow-100 text-yellow-800 border-yellow-300';
      case 'low':
        return 'bg-blue-100 text-blue-800 border-blue-300';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-300';
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'speeding':
        return '⚡';
      case 'idle':
        return '⏸️';
      case 'maintenance':
        return '🔧';
      case 'fuel':
        return '⛽';
      default:
        return '⚠️';
    }
  };

  const formatTimestamp = (timestamp) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffMs = now - date;
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    return date.toLocaleString();
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-gray-500">Loading alerts...</div>
      </div>
    );
  }

  return (
    <div className="px-4 py-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Alerts Center</h2>
        <div className="text-sm text-gray-500">
          {alerts.length} active alert{alerts.length !== 1 ? 's' : ''}
        </div>
      </div>

      {alerts.length === 0 ? (
        <div className="bg-white shadow rounded-lg p-8 text-center">
          <div className="text-4xl mb-4">✅</div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">No Active Alerts</h3>
          <p className="text-gray-500">All vehicles are operating normally.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {alerts.map((alert) => (
            <div
              key={alert.id}
              className={`bg-white shadow rounded-lg border-l-4 ${getSeverityColor(alert.severity)}`}
            >
              <div className="p-5">
                <div className="flex items-start justify-between">
                  <div className="flex items-start">
                    <div className="text-2xl mr-4">{getTypeIcon(alert.type)}</div>
                    <div className="flex-1">
                      <div className="flex items-center mb-2">
                        <h3 className="text-lg font-semibold text-gray-900 mr-3">
                          {alert.message}
                        </h3>
                        <span className={`px-2 py-1 text-xs font-semibold rounded uppercase ${getSeverityColor(alert.severity)}`}>
                          {alert.severity}
                        </span>
                      </div>
                      <div className="text-sm text-gray-600 space-y-1">
                        <p>
                          <span className="font-medium">Vehicle:</span>{' '}
                          <Link
                            to={`/vehicles/${alert.vehicleId}`}
                            className="text-primary-600 hover:text-primary-800"
                          >
                            {alert.vehicleName} ({alert.vehicleId})
                          </Link>
                        </p>
                        <p>
                          <span className="font-medium">Type:</span> {alert.type}
                        </p>
                        <p>
                          <span className="font-medium">Time:</span> {formatTimestamp(alert.timestamp)}
                        </p>
                      </div>
                    </div>
                  </div>
                  <Link
                    to={`/vehicles/${alert.vehicleId}`}
                    className="ml-4 text-primary-600 hover:text-primary-800 text-sm font-medium"
                  >
                    View Vehicle →
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Alerts;

