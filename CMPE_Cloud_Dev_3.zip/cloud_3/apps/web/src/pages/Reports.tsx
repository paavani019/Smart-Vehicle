import { useState } from 'react'
import { useQuery } from '@tanstack/react-query'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { api } from '@/lib/api'
import { FileText, Download } from 'lucide-react'
import { formatDateTime } from '@/lib/utils'

export function Reports() {
  const [generating, setGenerating] = useState(false)

  const { data: reportsData, refetch } = useQuery({
    queryKey: ['reports'],
    queryFn: () => api.getReports().then(res => res.data),
  })

  const handleGenerate = async (kind: string) => {
    setGenerating(true)
    try {
      const endDate = new Date().toISOString().split('T')[0]
      const startDate = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
        .toISOString()
        .split('T')[0]

      await api.generateReport(kind, { start: startDate, end: endDate })
      refetch()
    } finally {
      setGenerating(false)
    }
  }

  const reports = reportsData?.reports || []

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Reports</h1>
        <p className="text-muted-foreground mt-1">
          Generate and download fleet reports
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {['daily', 'weekly', 'utilization', 'driver_scorecards'].map((kind) => (
          <Card key={kind} className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <FileText className="h-8 w-8 text-primary" />
                <Button
                  size="sm"
                  onClick={() => handleGenerate(kind)}
                  disabled={generating}
                >
                  Generate
                </Button>
              </div>
              <h3 className="font-semibold capitalize">
                {kind.replace('_', ' ')}
              </h3>
              <p className="text-sm text-muted-foreground mt-1">
                {kind === 'daily' && 'Daily fleet summary'}
                {kind === 'weekly' && 'Weekly performance'}
                {kind === 'utilization' && 'Vehicle utilization'}
                {kind === 'driver_scorecards' && 'Driver performance'}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Reports</CardTitle>
        </CardHeader>
        <CardContent>
          {reports.length > 0 ? (
            <div className="space-y-3">
              {reports.map((report: any) => (
                <div
                  key={report.report_id}
                  className="flex items-center justify-between p-4 bg-gray-50 rounded-lg"
                >
                  <div className="flex items-center gap-4">
                    <FileText className="h-5 w-5 text-primary" />
                    <div>
                      <p className="font-medium capitalize">
                        {report.kind.replace('_', ' ')}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {formatDateTime(report.created_at)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <span
                      className={`px-3 py-1 text-xs font-medium rounded-full ${
                        report.status === 'completed'
                          ? 'bg-green-100 text-green-700'
                          : 'bg-yellow-100 text-yellow-700'
                      }`}
                    >
                      {report.status}
                    </span>
                    {report.status === 'completed' && (
                      <Button size="sm" variant="outline">
                        <Download className="h-4 w-4 mr-1" />
                        Download
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-center text-muted-foreground py-8">
              No reports generated yet
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  )
}

