import { useEffect, useRef, useState } from 'react';
import mapboxgl from 'mapbox-gl';
import { fetchTelemetry } from '../api/api';

// Note: You'll need to set your Mapbox access token
// For demo purposes, we'll use a placeholder. Replace with your actual token.
mapboxgl.accessToken = import.meta.env.VITE_MAPBOX_TOKEN || 'pk.eyJ1IjoibWFwYm94IiwiYSI6ImNpejY4NXVycTA2emYycXBndHRqcmZ3N3gifQ.rJcFIG214AriISLbB6B5aw';

const MapView = () => {
  const mapContainer = useRef(null);
  const map = useRef(null);
  const markers = useRef({});
  const [vehicles, setVehicles] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (map.current) return; // Initialize map only once

    map.current = new mapboxgl.Map({
      container: mapContainer.current,
      style: 'mapbox://styles/mapbox/streets-v12',
      center: [-74.0060, 40.7128], // New York City
      zoom: 11,
    });

    map.current.addControl(new mapboxgl.NavigationControl());
  }, []);

  useEffect(() => {
    const loadVehicles = async () => {
      try {
        const data = await fetchTelemetry();
        setVehicles(data);
        setLoading(false);
      } catch (error) {
        console.error('Error loading vehicles:', error);
        setLoading(false);
      }
    };

    loadVehicles();
    const interval = setInterval(loadVehicles, 10000); // Update every 10 seconds

    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (!map.current || vehicles.length === 0) return;

    // Remove old markers
    Object.values(markers.current).forEach(marker => marker.remove());
    markers.current = {};

    // Add new markers
    vehicles.forEach((vehicle) => {
      const getStatusColor = (status) => {
        switch (status) {
          case 'active':
            return '#10b981'; // green
          case 'idle':
            return '#f59e0b'; // yellow
          case 'maintenance':
            return '#ef4444'; // red
          default:
            return '#6b7280'; // gray
        }
      };

      const el = document.createElement('div');
      el.className = 'vehicle-marker';
      el.style.width = '20px';
      el.style.height = '20px';
      el.style.borderRadius = '50%';
      el.style.backgroundColor = getStatusColor(vehicle.status);
      el.style.border = '2px solid white';
      el.style.cursor = 'pointer';
      el.style.boxShadow = '0 2px 4px rgba(0,0,0,0.3)';

      const marker = new mapboxgl.Marker(el)
        .setLngLat([vehicle.location.lng, vehicle.location.lat])
        .setPopup(
          new mapboxgl.Popup({ offset: 25 }).setHTML(
            `<div class="p-2">
              <h3 class="font-bold">${vehicle.name}</h3>
              <p class="text-sm">ID: ${vehicle.id}</p>
              <p class="text-sm">Status: ${vehicle.status}</p>
              <p class="text-sm">Speed: ${vehicle.speed} km/h</p>
              <p class="text-sm">Fuel: ${vehicle.fuel}%</p>
            </div>`
          )
        )
        .addTo(map.current);

      markers.current[vehicle.id] = marker;
    });
  }, [vehicles]);

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="text-gray-500">Loading map...</div>
      </div>
    );
  }

  return (
    <div className="px-4 py-6">
      <h2 className="text-2xl font-bold text-gray-900 mb-4">Real-Time Fleet Map</h2>
      <div className="bg-white shadow rounded-lg overflow-hidden">
        <div className="p-4 border-b border-gray-200">
          <div className="flex flex-wrap gap-4">
            <div className="flex items-center">
              <div className="w-4 h-4 rounded-full bg-green-500 mr-2"></div>
              <span className="text-sm text-gray-700">Active</span>
            </div>
            <div className="flex items-center">
              <div className="w-4 h-4 rounded-full bg-yellow-500 mr-2"></div>
              <span className="text-sm text-gray-700">Idle</span>
            </div>
            <div className="flex items-center">
              <div className="w-4 h-4 rounded-full bg-red-500 mr-2"></div>
              <span className="text-sm text-gray-700">Maintenance</span>
            </div>
          </div>
        </div>
        <div ref={mapContainer} className="w-full h-[600px]" />
      </div>
      <p className="text-sm text-gray-500 mt-2">
        💡 Note: To use Mapbox, set VITE_MAPBOX_TOKEN in your .env file. For demo, you can use Leaflet as an alternative.
      </p>
    </div>
  );
};

export default MapView;

