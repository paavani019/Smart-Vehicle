"""Database connection and session management"""

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.orm import declarative_base
from app.config import settings

# Convert postgres:// to postgresql:// for SQLAlchemy
DATABASE_URL = settings.DATABASE_URL.replace("postgresql://", "postgresql+asyncpg://")
TIMESCALE_URL = settings.TIMESCALE_URL.replace("postgresql://", "postgresql+asyncpg://")

# Create async engines
engine = create_async_engine(DATABASE_URL, echo=False, future=True)
timescale_engine = create_async_engine(TIMESCALE_URL, echo=False, future=True)

# Session factory
AsyncSessionLocal = async_sessionmaker(
    engine,
    class_=AsyncSession,
    expire_on_commit=False
)

TimescaleSessionLocal = async_sessionmaker(
    timescale_engine,
    class_=AsyncSession,
    expire_on_commit=False
)

Base = declarative_base()


async def init_db():
    """Initialize database connection"""
    async with engine.begin() as conn:
        # Create tables if they don't exist (in production, use Alembic migrations)
        pass


async def get_db():
    """Dependency for getting database session"""
    async with AsyncSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()


async def get_timescale_db():
    """Dependency for getting TimescaleDB session"""
    async with TimescaleSessionLocal() as session:
        try:
            yield session
        finally:
            await session.close()

