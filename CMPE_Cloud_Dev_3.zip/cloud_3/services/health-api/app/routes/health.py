"""Health scoring routes"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from datetime import datetime, timedelta
import redis.asyncio as redis

from app.database import get_db, get_timescale_db
from app.schemas import HealthScore, HealthHistory
from app.ml.model_manager import model_manager
from app.config import settings

router = APIRouter()

# Redis client for caching
redis_client: redis.Redis | None = None


async def get_redis():
    """Get Redis client"""
    global redis_client
    if redis_client is None:
        redis_client = redis.from_url(settings.REDIS_URL)
    return redis_client


@router.get("/score/{vehicle_id}", response_model=HealthScore)
async def get_health_score(
    vehicle_id: str,
    db: AsyncSession = Depends(get_db),
    timescale_db: AsyncSession = Depends(get_timescale_db)
):
    """Get current health score for a vehicle (aggregated from telemetry)"""
    
    # Check if vehicle exists
    result = await db.execute(
        text("SELECT vehicle_id FROM vehicles WHERE vehicle_id = :vehicle_id"),
        {"vehicle_id": vehicle_id}
    )
    vehicle = result.fetchone()
    if not vehicle:
        raise HTTPException(status_code=404, detail=f"Vehicle {vehicle_id} not found")
    
    # Get component-level features
    query = text("""
        SELECT 
            AVG(coolant_temp) as avg_coolant_temp,
            AVG(battery_voltage) as avg_battery_voltage,
            AVG(rpm) as avg_rpm,
            AVG(fuel_level) as avg_fuel_level,
            SUM(CASE WHEN idle_flag THEN 1 ELSE 0 END)::float / NULLIF(COUNT(*), 0)::float as idle_time_pct
        FROM telemetry_records
        WHERE vehicle_id = :vehicle_id
        AND ts >= NOW() - INTERVAL '7 days'
    """)
    
    result = await timescale_db.execute(query, {"vehicle_id": vehicle_id})
    row = result.fetchone()
    
    # Calculate component scores
    components = {}
    
    if row and row[0]:
        # Engine/Cooling score
        coolant_temp = float(row[0])
        if coolant_temp < 90:
            components['engine'] = 95.0
        elif coolant_temp < 95:
            components['engine'] = 80.0
        else:
            components['engine'] = 60.0
        
        # Battery score
        battery = float(row[1]) if row[1] else 12.5
        if battery >= 12.4:
            components['battery'] = 95.0
        elif battery >= 12.0:
            components['battery'] = 75.0
        else:
            components['battery'] = 50.0
        
        # Transmission/Drive score (based on RPM)
        rpm = float(row[2]) if row[2] else 2000
        if rpm < 3000:
            components['transmission'] = 90.0
        else:
            components['transmission'] = 75.0
        
        # Fuel system score
        fuel = float(row[3]) if row[3] else 50
        components['fuel_system'] = 90.0  # Simplified
        
        # Overall efficiency (idle time penalty)
        idle_pct = float(row[4]) if row[4] else 0.1
        if idle_pct < 0.2:
            components['efficiency'] = 95.0
        elif idle_pct < 0.4:
            components['efficiency'] = 75.0
        else:
            components['efficiency'] = 60.0
    else:
        # No data - use defaults
        components = {
            'engine': 85.0,
            'battery': 85.0,
            'transmission': 85.0,
            'fuel_system': 85.0,
            'efficiency': 85.0
        }
    
    # Calculate overall health score
    overall_score = sum(components.values()) / len(components)
    
    # Determine status
    if overall_score >= settings.HEALTH_SCORE_GOOD:
        status = "Excellent"
    elif overall_score >= settings.HEALTH_SCORE_WARNING:
        status = "Good"
    elif overall_score >= settings.HEALTH_SCORE_CRITICAL:
        status = "Fair"
    else:
        status = "Poor"
    
    # Cache score in Redis
    redis_conn = await get_redis()
    await redis_conn.setex(
        f"health:score:{vehicle_id}",
        300,  # 5 min TTL
        str(overall_score)
    )
    
    return HealthScore(
        vehicle_id=vehicle_id,
        health_score=round(overall_score, 2),
        components=components,
        status=status,
        last_updated=datetime.utcnow()
    )


@router.get("/history/{vehicle_id}", response_model=HealthHistory)
async def get_health_history(
    vehicle_id: str,
    days: int = 30,
    timescale_db: AsyncSession = Depends(get_timescale_db)
):
    """Get historical health score trend"""
    
    # Query daily aggregated data
    query = text("""
        SELECT 
            DATE(bucket) as date,
            AVG(avg_coolant_temp) as coolant,
            AVG(avg_battery_voltage) as battery,
            AVG(idle_count)::float / NULLIF(AVG(record_count)::float, 0) as idle_pct
        FROM telemetry_daily
        WHERE vehicle_id = :vehicle_id
        AND bucket >= NOW() - INTERVAL ':days days'
        GROUP BY DATE(bucket)
        ORDER BY date DESC
    """)
    
    result = await timescale_db.execute(
        query,
        {"vehicle_id": vehicle_id, "days": days}
    )
    rows = result.fetchall()
    
    history = []
    for row in rows:
        # Calculate daily health score
        score = 100.0
        
        if row[1]:  # coolant
            coolant = float(row[1])
            if coolant > 95:
                score -= 20
            elif coolant > 90:
                score -= 10
        
        if row[2]:  # battery
            battery = float(row[2])
            if battery < 12.0:
                score -= 25
            elif battery < 12.4:
                score -= 10
        
        if row[3]:  # idle
            idle = float(row[3])
            score -= min(20, idle * 50)
        
        history.append({
            "timestamp": row[0].isoformat(),
            "score": max(0, min(100, round(score, 2)))
        })
    
    return HealthHistory(
        vehicle_id=vehicle_id,
        history=history
    )

