# Smart Vehicle Cloud - Architecture

## System Overview

The Smart Vehicle Cloud is a production-grade platform for vehicle data ingestion, predictive maintenance, and real-time fleet monitoring.

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                        Frontend Layer                            │
│  React + Vite + TypeScript + Tailwind + shadcn/ui              │
│  Pages: Overview | Vehicles | Alerts | Reports | Maintenance   │
└───────────────────────────┬─────────────────────────────────────┘
                            │ HTTPS/WSS
┌───────────────────────────▼─────────────────────────────────────┐
│                      API Gateway (nginx)                         │
│                      Rate Limiting & Auth                        │
└───────────────────────────┬─────────────────────────────────────┘
                            │
           ┌────────────────┼────────────────┐
           │                │                │
┌──────────▼──────┐  ┌─────▼──────┐  ┌─────▼──────┐
│ Ingestion API   │  │ Health API  │  │ Analytics  │
│ - Data Upload   │  │ - ML Model  │  │ - Reports  │
│ - Validation    │  │ - Scoring   │  │ - KPIs     │
│ - Streaming     │  │ - Predict   │  │ - Queries  │
└────────┬────────┘  └─────┬──────┘  └─────┬──────┘
         │                 │                │
         │           ┌─────▼──────┐         │
         │           │ Alerts API │         │
         │           │ - Rules    │         │
         │           │ - Notify   │         │
         │           └─────┬──────┘         │
         │                 │                │
┌────────▼─────────────────▼────────────────▼────────┐
│                 Message Bus (Kafka)                 │
│  Topics: telemetry.raw, telemetry.processed,      │
│          alerts.events                              │
└─────────────────┬───────────────────────────────────┘
                  │
        ┌─────────┼─────────┐
┌───────▼───────┐ │ ┌───────▼───────┐
│ Preprocess    │ │ │ Analytics     │
│ Worker        │ │ │ Worker        │
│ - Validate    │ │ │ - Aggregate   │
│ - Normalize   │ │ │ - Reports     │
│ - Anonymize   │ │ │ - Health      │
└───────┬───────┘ │ └───────┬───────┘
        │         │         │
┌───────▼─────────▼─────────▼───────┐
│         Storage Layer              │
│ - PostgreSQL (relational)          │
│ - TimescaleDB (time-series)        │
│ - Redis (cache)                    │
│ - MinIO (objects)                  │
└────────────────────────────────────┘
```

## Technology Stack

### Frontend
- **Framework**: React 18 + Vite
- **Language**: TypeScript
- **Styling**: Tailwind CSS + shadcn/ui
- **State Management**: TanStack Query (React Query)
- **Routing**: React Router v6
- **Charts**: Recharts
- **Maps**: Leaflet + React-Leaflet

### Backend Services (Python FastAPI)
- **ingestion-api**: Data ingestion, validation, Kafka streaming
- **health-api**: ML predictions, health scoring
- **analytics-api**: Time analytics, reports generation
- **alerts-api**: Rule engine, notifications

### Workers (Python)
- **preprocess-worker**: Kafka consumer, validation, normalization
- **analytics-worker**: Scheduled aggregations, reports

### Data Layer
- **PostgreSQL 15**: Relational data (vehicles, users, alerts, reports)
- **TimescaleDB**: Time-series telemetry with continuous aggregates
- **Kafka (Redpanda)**: Event streaming (3 topics)
- **Redis**: Caching (latest telemetry, sessions)
- **MinIO**: Object storage (raw data, reports)

### Observability
- **Prometheus**: Metrics collection
- **Grafana**: Dashboards
- **OpenTelemetry**: Distributed tracing

## Data Flow

### 1. Ingestion Pipeline
```
Vehicle → Ingestion API → Kafka (raw) → Preprocess Worker
                                      → TimescaleDB
                                      → Kafka (processed)
```

### 2. Alert Pipeline
```
Telemetry → Rule Engine → Alert Events → Kafka → Notifications
                                      → Alert Events Table
```

### 3. Analytics Pipeline
```
TimescaleDB → Analytics Worker → Aggregations
                              → Reports (MinIO)
                              → Reports Table
```

## API Endpoints

### Ingestion API (`/v1`)
- `POST /data/upload` - Multipart file upload
- `POST /telemetry/batch` - Batch telemetry ingestion
- `GET /telemetry/latest` - Latest telemetry snapshot
- `WS /events` - Real-time event stream

### Health API (`/v1`)
- `GET /maintenance/predict/{vehicleId}` - Predict maintenance
- `GET /health/score/{vehicleId}` - Health score
- `POST /maintenance/report` - Create maintenance report
- `GET /maintenance/alerts` - Maintenance alerts

### Analytics API (`/v1`)
- `GET /analytics/kpi` - Fleet KPIs
- `GET /analytics/time-summary` - Time analytics
- `GET /analytics/daily-report` - Daily report
- `POST /reports/generate` - Generate report

### Alerts API (`/v1`)
- `GET /alerts` - List alerts
- `POST /alerts` - Create alert rule
- `PUT /alerts/{id}/acknowledge` - Acknowledge alert
- `PUT /alerts/{id}/resolve` - Resolve alert
- `POST /notifications/send` - Send notification

## Security

### Authentication & Authorization
- JWT tokens (HS256 in dev, RS256 in prod)
- Role-Based Access Control (RBAC): admin, operator, driver
- Token expiration: 60 minutes (configurable)

### API Security
- Rate limiting per user/vehicle
- CORS configuration
- Input validation with Pydantic
- SQL injection prevention with parameterized queries

### Network Security
- mTLS between services (configurable)
- Network segmentation in Kubernetes
- Secrets management via environment variables

## Scalability

### Horizontal Scaling
- All FastAPI services are stateless
- Workers can be scaled independently
- Kafka consumer groups for parallelism

### Database Scaling
- TimescaleDB compression & retention policies
- PostgreSQL read replicas
- Redis cluster for cache
- MinIO distributed mode

### Performance Optimizations
- TimescaleDB continuous aggregates
- Redis caching (5 min TTL)
- Kafka batching
- Database connection pooling

## Deployment

### Docker Compose (Dev)
```bash
make up      # Start all services
make seed    # Seed database
make simulate # Start telemetry simulator
```

### Kubernetes (Production)
- Helm charts for each service
- HPA for autoscaling
- PVC for persistent storage
- Ingress for external access

## Monitoring & Observability

### Metrics (Prometheus)
- Request rate, latency, errors
- Kafka lag
- Database connection pool
- Validation success rate

### Dashboards (Grafana)
- Fleet Overview
- Ingestion Pipeline
- Alert Volume
- System Health

### Logging
- Structured JSON logs
- Centralized logging (ELK stack in prod)
- Log levels: DEBUG, INFO, WARNING, ERROR

## Disaster Recovery

### Backup Strategy
- PostgreSQL: Daily full backup + WAL archiving
- TimescaleDB: Continuous aggregates reduce data volume
- MinIO: Object versioning enabled
- Kafka: Retention policy (7 days)

### High Availability
- Multi-region deployment
- Database replication
- Kafka replication factor: 3
- Load balancer health checks

