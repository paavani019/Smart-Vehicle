"""
Preprocess Worker - Kafka Consumer
Consumes telemetry.raw, performs validation, normalization, and writes to TimescaleDB
"""

import asyncio
import asyncpg
import json
import logging
from datetime import datetime
from aiokafka import AIOKafkaConsumer, AIOKafkaProducer
from minio import Minio
import os

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Configuration
KAFKA_BOOTSTRAP = os.getenv('KAFKA_BOOTSTRAP_SERVERS', 'localhost:9092')
DATABASE_URL = os.getenv('DATABASE_URL', 'postgresql://postgres:postgres@localhost:5432/fleet_db')
TIMESCALE_URL = os.getenv('TIMESCALE_URL', 'postgresql://postgres:postgres@localhost:5433/telemetry_db')
MINIO_ENDPOINT = os.getenv('MINIO_ENDPOINT', 'localhost:9000')
MINIO_ACCESS_KEY = os.getenv('MINIO_ACCESS_KEY', 'minioadmin')
MINIO_SECRET_KEY = os.getenv('MINIO_SECRET_KEY', 'minioadmin')

MAX_DRIFT_MS = 2000


class PreprocessWorker:
    def __init__(self):
        self.consumer = None
        self.producer = None
        self.timescale_pool = None
        self.minio_client = None
    
    async def start(self):
        """Initialize connections"""
        logger.info("Starting Preprocess Worker...")
        
        # Kafka consumer
        self.consumer = AIOKafkaConsumer(
            'telemetry.raw',
            bootstrap_servers=KAFKA_BOOTSTRAP,
            group_id='preprocess-worker',
            value_deserializer=lambda m: json.loads(m.decode('utf-8')),
            auto_offset_reset='earliest'
        )
        await self.consumer.start()
        logger.info("✅ Kafka consumer started")
        
        # Kafka producer
        self.producer = AIOKafkaProducer(
            bootstrap_servers=KAFKA_BOOTSTRAP,
            value_serializer=lambda v: json.dumps(v).encode('utf-8')
        )
        await self.producer.start()
        logger.info("✅ Kafka producer started")
        
        # TimescaleDB connection pool
        self.timescale_pool = await asyncpg.create_pool(
            TIMESCALE_URL.replace('postgresql://', ''),
            min_size=2,
            max_size=10
        )
        logger.info("✅ TimescaleDB pool created")
        
        # MinIO client
        self.minio_client = Minio(
            MINIO_ENDPOINT,
            access_key=MINIO_ACCESS_KEY,
            secret_key=MINIO_SECRET_KEY,
            secure=False
        )
        logger.info("✅ MinIO client initialized")
    
    async def stop(self):
        """Cleanup connections"""
        if self.consumer:
            await self.consumer.stop()
        if self.producer:
            await self.producer.stop()
        if self.timescale_pool:
            await self.timescale_pool.close()
    
    def validate_schema(self, record: dict) -> tuple[bool, list[str]]:
        """Validate record schema and data quality"""
        errors = []
        
        if 'vehicleId' not in record:
            errors.append('MISSING_VEHICLE_ID')
        
        if 'ts' not in record:
            errors.append('MISSING_TIMESTAMP')
        
        # Check timestamp drift
        try:
            ts = datetime.fromisoformat(record['ts'].replace('Z', '+00:00'))
            drift_ms = abs((datetime.utcnow() - ts).total_seconds() * 1000)
            if drift_ms > MAX_DRIFT_MS:
                errors.append(f'TIMESTAMP_DRIFT:{int(drift_ms)}ms')
        except Exception as e:
            errors.append(f'INVALID_TIMESTAMP:{str(e)}')
        
        # Validate GPS if present
        if 'gps' in record and record['gps']:
            lat, lon = record['gps']
            if abs(lat) > 90 or abs(lon) > 180:
                errors.append('INVALID_GPS')
        
        # Validate ranges
        if 'speed' in record and record['speed']:
            if record['speed'] < 0 or record['speed'] > 300:
                errors.append('INVALID_SPEED')
        
        if 'batteryVoltage' in record and record['batteryVoltage']:
            if record['batteryVoltage'] < 0 or record['batteryVoltage'] > 20:
                errors.append('INVALID_BATTERY')
        
        return len(errors) == 0, errors
    
    def normalize_units(self, record: dict) -> dict:
        """Normalize units to SI/standard format"""
        normalized = record.copy()
        
        # Ensure speed is in km/h
        if 'speed' in normalized and normalized['speed'] is not None:
            normalized['speedKmph'] = float(normalized['speed'])
        
        # Ensure temperatures are in Celsius
        if 'coolantTemp' in normalized and normalized['coolantTemp'] is not None:
            normalized['coolantC'] = float(normalized['coolantTemp'])
        
        # Battery voltage
        if 'batteryVoltage' in normalized and normalized['batteryVoltage'] is not None:
            normalized['batteryV'] = float(normalized['batteryVoltage'])
        
        # Determine idle flag
        normalized['idle'] = (
            normalized.get('speed', 0) == 0 and
            normalized.get('engineStatus') in ['ON', 'IDLE']
        )
        
        return normalized
    
    async def write_to_timescale(self, record: dict):
        """Write processed record to TimescaleDB"""
        async with self.timescale_pool.acquire() as conn:
            try:
                await conn.execute("""
                    INSERT INTO telemetry_records (
                        vehicle_id, ts, lat, lon, speed, rpm, fuel_level,
                        engine_status, idle_flag, coolant_temp, battery_voltage,
                        odometer_km, gear, flags
                    ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
                    ON CONFLICT (vehicle_id, ts) DO NOTHING
                """,
                    record['vehicleId'],
                    datetime.fromisoformat(record['ts'].replace('Z', '+00:00')),
                    record.get('gps', [None, None])[0] if record.get('gps') else None,
                    record.get('gps', [None, None])[1] if record.get('gps') else None,
                    record.get('speedKmph'),
                    record.get('rpm'),
                    record.get('fuelLevel'),
                    record.get('engineStatus'),
                    record.get('idle', False),
                    record.get('coolantC'),
                    record.get('batteryV'),
                    record.get('odometerKm'),
                    record.get('gear'),
                    json.dumps(record.get('flags', {}))
                )
            except Exception as e:
                logger.error(f"Failed to write to TimescaleDB: {e}")
    
    async def process_message(self, message):
        """Process a single telemetry message"""
        try:
            record = message.value
            vehicle_id = record.get('vehicleId', 'unknown')
            
            # Step 1: Validate schema
            is_valid, errors = self.validate_schema(record)
            
            flags = {
                'schema': 'VALID' if is_valid else 'INVALID',
                'errors': errors if not is_valid else [],
                'missing': sum(1 for k in ['gps', 'speed', 'rpm'] if k not in record or record[k] is None)
            }
            
            if not is_valid:
                logger.warning(f"Validation failed for {vehicle_id}: {errors}")
                # Still process but mark as invalid
            
            # Step 2: Normalize units
            normalized = self.normalize_units(record)
            normalized['flags'] = flags
            
            # Step 3: Write to TimescaleDB
            await self.write_to_timescale(normalized)
            
            # Step 4: Publish processed record to Kafka
            await self.producer.send_and_wait(
                'telemetry.processed',
                value=normalized,
                key=vehicle_id.encode('utf-8')
            )
            
            logger.debug(f"✅ Processed {vehicle_id} @ {record.get('ts')}")
        
        except Exception as e:
            logger.error(f"Error processing message: {e}")
    
    async def run(self):
        """Main worker loop"""
        await self.start()
        
        try:
            logger.info("🔄 Preprocess worker running, waiting for messages...")
            async for message in self.consumer:
                await self.process_message(message)
        
        except KeyboardInterrupt:
            logger.info("Shutting down...")
        
        finally:
            await self.stop()


async def main():
    worker = PreprocessWorker()
    await worker.run()


if __name__ == "__main__":
    asyncio.run(main())

