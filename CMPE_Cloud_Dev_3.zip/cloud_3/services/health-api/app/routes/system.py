"""System health and status routes"""

from fastapi import APIRouter
from app.ml.model_manager import model_manager

router = APIRouter()


@router.get("/health")
async def system_health():
    """System health check"""
    return {
        "status": "healthy",
        "model_loaded": model_manager.model is not None,
        "scaler_loaded": model_manager.scaler is not None
    }


@router.get("/model/info")
async def model_info():
    """Get ML model information"""
    if model_manager.model is None:
        return {
            "status": "no_model",
            "message": "Model not loaded, using rule-based predictions"
        }
    
    return {
        "status": "loaded",
        "model_type": type(model_manager.model).__name__,
        "features": model_manager.feature_names,
        "n_features": len(model_manager.feature_names)
    }

