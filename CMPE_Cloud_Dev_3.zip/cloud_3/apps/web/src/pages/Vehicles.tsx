import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Truck } from 'lucide-react'

export function Vehicles() {
  const mockVehicles = [
    { id: 'VEH-001', plate: 'TXA-1234', status: 'active', driver: 'John Driver', location: 'Austin, TX' },
    { id: 'VEH-002', plate: 'TXA-5678', status: 'active', driver: 'Jane Transporter', location: 'Dallas, TX' },
    { id: 'VEH-003', plate: 'TXA-9012', status: 'active', driver: 'Mike Hauler', location: 'Houston, TX' },
    { id: 'VEH-004', plate: 'TXA-3456', status: 'active', driver: 'Sarah Driver', location: 'Phoenix, AZ' },
    { id: 'VEH-005', plate: 'TXA-7890', status: 'maintenance', driver: 'Unassigned', location: 'Depot' },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Vehicles</h1>
        <p className="text-muted-foreground mt-1">Manage and monitor fleet vehicles</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>All Vehicles</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {mockVehicles.map((vehicle) => (
              <div
                key={vehicle.id}
                className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
              >
                <div className="flex items-center gap-4">
                  <div className="bg-primary/10 p-3 rounded-lg">
                    <Truck className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <p className="font-medium">{vehicle.plate}</p>
                    <p className="text-sm text-muted-foreground">{vehicle.id}</p>
                  </div>
                </div>
                <div className="flex items-center gap-6">
                  <div>
                    <p className="text-sm text-muted-foreground">Driver</p>
                    <p className="text-sm font-medium">{vehicle.driver}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Location</p>
                    <p className="text-sm font-medium">{vehicle.location}</p>
                  </div>
                  <span
                    className={`px-3 py-1 text-xs font-medium rounded-full ${
                      vehicle.status === 'active'
                        ? 'bg-green-100 text-green-700'
                        : 'bg-yellow-100 text-yellow-700'
                    }`}
                  >
                    {vehicle.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

