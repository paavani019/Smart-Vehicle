"""Alert management routes"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from pydantic import BaseModel
from typing import Optional, Dict, List
from datetime import datetime
from uuid import UUID, uuid4
import redis.asyncio as redis

from app.database import get_db
from app.kafka_client import kafka_client
from app.rule_engine import rule_engine
from app.config import settings

router = APIRouter()

redis_client: redis.Redis | None = None


async def get_redis():
    """Get Redis client"""
    global redis_client
    if redis_client is None:
        redis_client = redis.from_url(settings.REDIS_URL)
    return redis_client


class AlertRuleCreate(BaseModel):
    """Create alert rule"""
    name: str
    description: Optional[str] = None
    condition: Dict
    severity: str  # LOW, MEDIUM, HIGH, CRITICAL
    actions: Optional[Dict] = None
    scope: Optional[Dict] = None


class AlertAcknowledge(BaseModel):
    """Acknowledge alert"""
    user_id: str


class AlertResolve(BaseModel):
    """Resolve alert"""
    user_id: str
    resolution_notes: Optional[str] = None


@router.get("")
async def get_alerts(
    severity: Optional[str] = None,
    vehicle_id: Optional[str] = None,
    status: Optional[str] = None,  # active, acknowledged, resolved
    limit: int = 50,
    db: AsyncSession = Depends(get_db)
):
    """Get active & historical alerts with filters"""
    
    query_parts = ["SELECT * FROM alert_events WHERE 1=1"]
    params = {}
    
    if severity:
        query_parts.append("AND severity = :severity")
        params["severity"] = severity
    
    if vehicle_id:
        query_parts.append("AND vehicle_id = :vehicle_id")
        params["vehicle_id"] = vehicle_id
    
    if status == "active":
        query_parts.append("AND resolved_at IS NULL")
    elif status == "acknowledged":
        query_parts.append("AND acknowledged_at IS NOT NULL AND resolved_at IS NULL")
    elif status == "resolved":
        query_parts.append("AND resolved_at IS NOT NULL")
    
    query_parts.append("ORDER BY created_at DESC LIMIT :limit")
    params["limit"] = limit
    
    query = text(" ".join(query_parts))
    result = await db.execute(query, params)
    rows = result.fetchall()
    
    alerts = []
    for row in rows:
        alerts.append({
            "event_id": str(row[0]),
            "vehicle_id": row[1],
            "rule_id": str(row[2]) if row[2] else None,
            "severity": row[3],
            "summary": row[4],
            "details": row[5],
            "created_at": row[6].isoformat(),
            "acknowledged_at": row[7].isoformat() if row[7] else None,
            "acknowledged_by": str(row[8]) if row[8] else None,
            "resolved_at": row[9].isoformat() if row[9] else None,
            "resolved_by": str(row[10]) if row[10] else None
        })
    
    return {
        "alerts": alerts,
        "total": len(alerts)
    }


@router.post("")
async def create_alert_rule(
    rule: AlertRuleCreate,
    db: AsyncSession = Depends(get_db)
):
    """Create custom alert rule using JSON DSL"""
    
    rule_id = uuid4()
    
    query = text("""
        INSERT INTO alert_rules (rule_id, name, description, condition, severity, actions, scope, enabled)
        VALUES (:rule_id, :name, :description, :condition, :severity, :actions, :scope, :enabled)
        RETURNING rule_id, name
    """)
    
    result = await db.execute(query, {
        "rule_id": rule_id,
        "name": rule.name,
        "description": rule.description,
        "condition": rule.condition,
        "severity": rule.severity,
        "actions": rule.actions or {},
        "scope": rule.scope or {},
        "enabled": True
    })
    await db.commit()
    
    row = result.fetchone()
    
    return {
        "rule_id": str(row[0]),
        "name": row[1],
        "status": "created",
        "message": f"Alert rule '{rule.name}' created successfully"
    }


@router.put("/{alert_id}/acknowledge")
async def acknowledge_alert(
    alert_id: str,
    ack: AlertAcknowledge,
    db: AsyncSession = Depends(get_db)
):
    """Acknowledge an alert"""
    
    query = text("""
        UPDATE alert_events
        SET acknowledged_at = :now, acknowledged_by = :user_id
        WHERE event_id = :alert_id
        RETURNING event_id, vehicle_id, summary
    """)
    
    result = await db.execute(query, {
        "alert_id": alert_id,
        "user_id": ack.user_id,
        "now": datetime.utcnow()
    })
    await db.commit()
    
    row = result.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail=f"Alert {alert_id} not found")
    
    return {
        "event_id": str(row[0]),
        "vehicle_id": row[1],
        "summary": row[2],
        "status": "acknowledged",
        "acknowledged_at": datetime.utcnow().isoformat()
    }


@router.put("/{alert_id}/resolve")
async def resolve_alert(
    alert_id: str,
    resolve: AlertResolve,
    db: AsyncSession = Depends(get_db)
):
    """Resolve an alert"""
    
    query = text("""
        UPDATE alert_events
        SET resolved_at = :now, resolved_by = :user_id
        WHERE event_id = :alert_id
        RETURNING event_id, vehicle_id, summary
    """)
    
    result = await db.execute(query, {
        "alert_id": alert_id,
        "user_id": resolve.user_id,
        "now": datetime.utcnow()
    })
    await db.commit()
    
    row = result.fetchone()
    if not row:
        raise HTTPException(status_code=404, detail=f"Alert {alert_id} not found")
    
    return {
        "event_id": str(row[0]),
        "vehicle_id": row[1],
        "summary": row[2],
        "status": "resolved",
        "resolved_at": datetime.utcnow().isoformat()
    }


@router.post("/evaluate")
async def evaluate_rules(
    context: Dict,
    db: AsyncSession = Depends(get_db)
):
    """
    Evaluate alert rules against provided context (for testing/manual triggers)
    Context should include: vehicle_id, speed, location, etc.
    """
    
    vehicle_id = context.get('vehicle_id')
    if not vehicle_id:
        raise HTTPException(status_code=400, detail="vehicle_id required in context")
    
    # Get vehicle status
    vehicle_query = text("SELECT status FROM vehicles WHERE vehicle_id = :vehicle_id")
    result = await db.execute(vehicle_query, {"vehicle_id": vehicle_id})
    vehicle_row = result.fetchone()
    vehicle_status = vehicle_row[0] if vehicle_row else "active"
    
    # Evaluate all rules
    triggered_alerts = rule_engine.evaluate_all(context)
    
    # Apply suppression
    filtered_alerts = [
        alert for alert in triggered_alerts
        if not rule_engine.should_suppress(alert, vehicle_status)
    ]
    
    # Check for deduplication
    redis_conn = await get_redis()
    unique_alerts = []
    
    for alert in filtered_alerts:
        # Check if similar alert exists in last N minutes
        dedup_key = f"alert:dedup:{vehicle_id}:{alert['rule_id']}"
        existing = await redis_conn.get(dedup_key)
        
        if not existing:
            # New alert - create it
            event_id = uuid4()
            
            insert_query = text("""
                INSERT INTO alert_events (event_id, vehicle_id, rule_id, severity, summary, details, created_at)
                VALUES (:event_id, :vehicle_id, :rule_id, :severity, :summary, :details, :created_at)
            """)
            
            await db.execute(insert_query, {
                "event_id": event_id,
                "vehicle_id": vehicle_id,
                "rule_id": alert['rule_id'],
                "severity": alert['severity'],
                "summary": alert['summary'],
                "details": alert.get('details', {}),
                "created_at": datetime.utcnow()
            })
            
            # Set dedup key
            await redis_conn.setex(
                dedup_key,
                settings.ALERT_DEDUP_WINDOW_MINUTES * 60,
                "1"
            )
            
            # Publish to Kafka
            await kafka_client.publish(
                settings.KAFKA_TOPIC_ALERTS,
                {
                    "eventId": str(event_id),
                    "vehicleId": vehicle_id,
                    "ruleId": alert['rule_id'],
                    "severity": alert['severity'],
                    "summary": alert['summary'],
                    "details": alert.get('details', {}),
                    "ts": datetime.utcnow().isoformat()
                },
                key=vehicle_id
            )
            
            unique_alerts.append({
                "event_id": str(event_id),
                **alert
            })
    
    await db.commit()
    
    return {
        "evaluated": len(triggered_alerts),
        "suppressed": len(triggered_alerts) - len(filtered_alerts),
        "deduplicated": len(filtered_alerts) - len(unique_alerts),
        "created": len(unique_alerts),
        "alerts": unique_alerts
    }

