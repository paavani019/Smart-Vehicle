"""
Analytics API - Time Analytics & Reports Generation Service
Provides analytics queries and generates fleet reports
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import logging

from app.config import settings
from app.routes import analytics, reports
from app.database import init_db

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events"""
    logger.info("Starting Analytics API...")
    await init_db()
    logger.info("✅ Analytics API ready")
    yield
    logger.info("Shutting down Analytics API...")


app = FastAPI(
    title="Fleet Analytics API",
    version="1.0.0",
    description="Time Analytics & Reports Generation Service",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(analytics.router, prefix="/v1/analytics", tags=["Analytics"])
app.include_router(reports.router, prefix="/v1/reports", tags=["Reports"])


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "Analytics API",
        "version": "1.0.0",
        "status": "running"
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "database": "connected"
    }

