"""
Health API - Predictive Maintenance & Health Scoring Service
Provides ML-based predictions for vehicle health and maintenance scheduling
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import logging

from app.config import settings
from app.routes import maintenance, health, system
from app.database import init_db
from app.ml.model_manager import model_manager

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events"""
    logger.info("Starting Health API...")
    await init_db()
    await model_manager.load_models()
    logger.info("✅ Health API ready")
    yield
    logger.info("Shutting down Health API...")


app = FastAPI(
    title="Fleet Health API",
    version="1.0.0",
    description="Predictive Maintenance & Health Scoring Service",
    lifespan=lifespan
)

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(maintenance.router, prefix="/v1/maintenance", tags=["Maintenance"])
app.include_router(health.router, prefix="/v1/health", tags=["Health"])
app.include_router(system.router, prefix="/v1/system", tags=["System"])


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "Health API",
        "version": "1.0.0",
        "status": "running"
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "database": "connected",
        "model_loaded": model_manager.model is not None
    }

